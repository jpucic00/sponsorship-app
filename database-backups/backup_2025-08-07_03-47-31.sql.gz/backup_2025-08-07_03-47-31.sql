PRAGMA foreign_keys=OFF;
BEGIN TRANSACTION;

CREATE TABLE "children" (
    "id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
    "firstName" TEXT NOT NULL,
    "lastName" TEXT NOT NULL,
    "dateOfBirth" DATETIME NOT NULL,
    "gender" TEXT NOT NULL,
    "schoolId" INTEGER NOT NULL,
    "class" TEXT NOT NULL,
    "fatherFullName" TEXT NOT NULL,
    "fatherAddress" TEXT,
    "fatherContact" TEXT,
    "motherFullName" TEXT NOT NULL,
    "motherAddress" TEXT,
    "motherContact" TEXT,
    "story" TEXT,
    "comment" TEXT,
    "dateEnteredRegister" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "lastProfileUpdate" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "isSponsored" BOOLEAN NOT NULL DEFAULT false,
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" DATETIME NOT NULL,
    CONSTRAINT "children_schoolId_fkey" FOREIGN KEY ("schoolId") REFERENCES "schools" ("id") ON DELETE RESTRICT ON UPDATE CASCADE
);

INSERT INTO children (id, firstName, lastName, dateOfBirth, gender, schoolId, class, fatherFullName, fatherAddress, fatherContact, motherFullName, motherAddress, motherContact, story, comment, dateEnteredRegister, lastProfileUpdate, isSponsored, createdAt, updatedAt) VALUES (41, 'EDINA', 'AYOO', '2007-05-24T00:00:00+00:00', 'Female', 2, 'S1', 'ANGELO ONGOM', NULL, '256776451583', 'APIO MAGRET', NULL, NULL, NULL, NULL, '2025-08-05T06:27:23.231+00:00', '2025-08-05T06:27:23.231+00:00', 1, '2025-08-05T06:27:23.232+00:00', '2025-08-05T06:27:23.232+00:00');
INSERT INTO children (id, firstName, lastName, dateOfBirth, gender, schoolId, class, fatherFullName, fatherAddress, fatherContact, motherFullName, motherAddress, motherContact, story, comment, dateEnteredRegister, lastProfileUpdate, isSponsored, createdAt, updatedAt) VALUES (42, 'XAVIOUR KERENYL', 'OTHII', '2006-08-09T00:00:00+00:00', 'Male', 2, 'S3', 'EMMANUEL ONGOM', 'AREMO', '+256785322031', 'AUMA ESTHER  BLACK', NULL, NULL, NULL, NULL, '2025-08-05T06:31:08.332+00:00', '2025-08-05T06:31:08.332+00:00', 1, '2025-08-05T06:31:08.333+00:00', '2025-08-05T06:31:08.333+00:00');
INSERT INTO children (id, firstName, lastName, dateOfBirth, gender, schoolId, class, fatherFullName, fatherAddress, fatherContact, motherFullName, motherAddress, motherContact, story, comment, dateEnteredRegister, lastProfileUpdate, isSponsored, createdAt, updatedAt) VALUES (43, 'FILBERT', 'ONYANGA', '2004-10-01T00:00:00+00:00', 'Male', 2, 'S4', 'SMUEL OCHEN', 'WILELA', '+256787449694', 'LEDINA AKONGO', NULL, NULL, NULL, NULL, '2025-08-05T06:35:10.543+00:00', '2025-08-05T06:46:51.377+00:00', 1, '2025-08-05T06:35:10.544+00:00', '2025-08-05T06:46:51.378+00:00');
INSERT INTO children (id, firstName, lastName, dateOfBirth, gender, schoolId, class, fatherFullName, fatherAddress, fatherContact, motherFullName, motherAddress, motherContact, story, comment, dateEnteredRegister, lastProfileUpdate, isSponsored, createdAt, updatedAt) VALUES (44, 'BONIFACE', 'OKENGO', '2004-10-01T00:00:00+00:00', 'Male', 2, 'S4', 'OLWOCH TONY FRANCIS', 'WILELA', '+256778843562', '-', NULL, NULL, NULL, NULL, '2025-08-05T06:37:58.696+00:00', '2025-08-05T06:49:31.731+00:00', 1, '2025-08-05T06:37:58.697+00:00', '2025-08-05T06:49:31.732+00:00');
INSERT INTO children (id, firstName, lastName, dateOfBirth, gender, schoolId, class, fatherFullName, fatherAddress, fatherContact, motherFullName, motherAddress, motherContact, story, comment, dateEnteredRegister, lastProfileUpdate, isSponsored, createdAt, updatedAt) VALUES (45, 'ARNOLD', 'OKELLO', '2002-05-14T00:00:00+00:00', 'Male', 2, 'S4', 'OCHEN BENARD', 'CHWAILAI', '+256784277955', 'AWILLI BETTY', NULL, NULL, NULL, NULL, '2025-08-05T06:40:38.565+00:00', '2025-08-05T06:41:08.370+00:00', 1, '2025-08-05T06:40:38.567+00:00', '2025-08-05T06:41:08.371+00:00');
INSERT INTO children (id, firstName, lastName, dateOfBirth, gender, schoolId, class, fatherFullName, fatherAddress, fatherContact, motherFullName, motherAddress, motherContact, story, comment, dateEnteredRegister, lastProfileUpdate, isSponsored, createdAt, updatedAt) VALUES (46, 'SIMON PETER', 'ODIA', '2003-02-18T00:00:00+00:00', 'Male', 2, 'S4', 'OCHEN NICHOLAS', 'ANGWEE', '-', 'ALELO SANTINA', NULL, NULL, NULL, NULL, '2025-08-05T06:52:47.907+00:00', '2025-08-05T06:53:40.892+00:00', 1, '2025-08-05T06:52:47.908+00:00', '2025-08-05T06:53:40.893+00:00');
INSERT INTO children (id, firstName, lastName, dateOfBirth, gender, schoolId, class, fatherFullName, fatherAddress, fatherContact, motherFullName, motherAddress, motherContact, story, comment, dateEnteredRegister, lastProfileUpdate, isSponsored, createdAt, updatedAt) VALUES (47, 'CHARLES', 'OPIO', '2003-02-15T00:00:00+00:00', 'Male', 2, 'S4', 'ARYON PETER NALLY', 'AREMO', '+256770345252', 'ANGOM JOSEPHINE', NULL, NULL, NULL, NULL, '2025-08-05T06:56:22.667+00:00', '2025-08-05T06:56:47.201+00:00', 1, '2025-08-05T06:56:22.668+00:00', '2025-08-05T06:56:47.202+00:00');
INSERT INTO children (id, firstName, lastName, dateOfBirth, gender, schoolId, class, fatherFullName, fatherAddress, fatherContact, motherFullName, motherAddress, motherContact, story, comment, dateEnteredRegister, lastProfileUpdate, isSponsored, createdAt, updatedAt) VALUES (48, 'MAXWEL ABAI', 'OMARA', '2005-01-01T00:00:00+00:00', 'Male', 2, 'S4', 'AYEPA JOHN ABAI', 'AREMO', '+256786457705', 'AWILLI MARGRET', NULL, NULL, NULL, NULL, '2025-08-05T07:01:12.634+00:00', '2025-08-05T07:01:32.117+00:00', 1, '2025-08-05T07:01:12.635+00:00', '2025-08-05T07:01:32.118+00:00');

CREATE TABLE "child_photos" (
    "id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
    "childId" INTEGER NOT NULL,
    "photoBase64" TEXT NOT NULL,
    "mimeType" TEXT NOT NULL,
    "fileName" TEXT,
    "fileSize" INTEGER,
    "description" TEXT,
    "uploadedAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "isProfile" BOOLEAN NOT NULL DEFAULT false,
    CONSTRAINT "child_photos_childId_fkey" FOREIGN KEY ("childId") REFERENCES "children" ("id") ON DELETE CASCADE ON UPDATE CASCADE
);

CREATE TABLE "schools" (
    "id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
    "name" TEXT NOT NULL,
    "location" TEXT,
    "isActive" BOOLEAN NOT NULL DEFAULT true
);

INSERT INTO schools (id, name, location, isActive) VALUES (2, 'ABIM SECONDARY SCHOOL', 'Abim', 1);
INSERT INTO schools (id, name, location, isActive) VALUES (3, 'ABIM TECHNICAL INSTITUTE', 'Abim', 1);
INSERT INTO schools (id, name, location, isActive) VALUES (4, 'ACHUKUDU COMMUNITY PRIMARY SCHOOL', 'Achukudu', 1);
INSERT INTO schools (id, name, location, isActive) VALUES (5, 'ADEA PRIMARY SCHOOL', 'Adea', 1);
INSERT INTO schools (id, name, location, isActive) VALUES (6, 'ADWARI SECONDARY SCHOOL', 'Adwari', 1);
INSERT INTO schools (id, name, location, isActive) VALUES (7, 'AKIGENO NURSERY AND PRIMARY SCHOOL', 'Akigeno', 1);
INSERT INTO schools (id, name, location, isActive) VALUES (8, 'AKWANGAGWEL PRIMARY SCHOOL', 'Akwangagwel', 1);
INSERT INTO schools (id, name, location, isActive) VALUES (9, 'ALIR PRIMARY SCHOOL', 'Alir', 1);
INSERT INTO schools (id, name, location, isActive) VALUES (10, 'ANKOLE INSTITUTE OF BUSINESS AND VOCATIONAL STUDIES', 'Mbarara', 1);
INSERT INTO schools (id, name, location, isActive) VALUES (11, 'APOSTLES OF JESUS SEMINARY', 'Moroto', 1);
INSERT INTO schools (id, name, location, isActive) VALUES (12, 'ARAPAI AGRICULTURAL COLLEGE', 'Soroti', 1);
INSERT INTO schools (id, name, location, isActive) VALUES (13, 'BUSITEMA UNIVERSITY SOROTI BRANCH', 'Soroti', 1);
INSERT INTO schools (id, name, location, isActive) VALUES (14, 'FATHER BASH FOUNDATION', 'Uganda', 1);
INSERT INTO schools (id, name, location, isActive) VALUES (15, 'FLORENCE NIGHTINGALE SCHOOL OF NURSING AND MIDWIFERY', 'Uganda', 1);
INSERT INTO schools (id, name, location, isActive) VALUES (16, 'GLORY NURSERY AND PRIMARY SCHOOL', 'Uganda', 1);
INSERT INTO schools (id, name, location, isActive) VALUES (17, 'GOOD DADDY NURSERY AND PRIMARY SCHOOL', 'Uganda', 1);
INSERT INTO schools (id, name, location, isActive) VALUES (18, 'GULU UNIVERSITY', 'Gulu', 1);
INSERT INTO schools (id, name, location, isActive) VALUES (19, 'HALCYON HIGH SCHOOL', 'Uganda', 1);
INSERT INTO schools (id, name, location, isActive) VALUES (20, 'HUMAN DEVELOPMENT TECHNICAL TRAINING SCHOOL', 'Lira', 1);
INSERT INTO schools (id, name, location, isActive) VALUES (21, 'IMMACULATE HEART OF MARY', 'Uganda', 1);
INSERT INTO schools (id, name, location, isActive) VALUES (22, 'INTERNATIONAL INSTITUTE OF HEALTH SCIENCES', 'Jinja', 1);
INSERT INTO schools (id, name, location, isActive) VALUES (23, 'JUBILEE 2000 SSS', 'Karenga', 1);
INSERT INTO schools (id, name, location, isActive) VALUES (24, 'KAMPALA INTERNATIONAL UNIVERSITY', 'Kampala', 1);
INSERT INTO schools (id, name, location, isActive) VALUES (25, 'KANGOLE GIRLS PRIMARY SCHOOL', 'Kangole', 1);
INSERT INTO schools (id, name, location, isActive) VALUES (26, 'KANGOLE GIRLS SECONDARY SCHOOL', 'Kangole', 1);
INSERT INTO schools (id, name, location, isActive) VALUES (27, 'KING''S KID PRIMARY SCHOOL', 'Uganda', 1);
INSERT INTO schools (id, name, location, isActive) VALUES (28, 'KOMUKUNY BOYS PRIMARY SCHOOL', 'Komukuny', 1);
INSERT INTO schools (id, name, location, isActive) VALUES (29, 'LIRA CENTRAL PRIMARY SCHOOL', 'Lira', 1);
INSERT INTO schools (id, name, location, isActive) VALUES (30, 'LOTUKE SEED SECONDARY SCHOOL', 'Lotuke', 1);
INSERT INTO schools (id, name, location, isActive) VALUES (31, 'LUZIRA SECONDARY SCHOOL', 'Luzira', 1);
INSERT INTO schools (id, name, location, isActive) VALUES (32, 'MAKERERE UNIVERSITY', 'Kampala', 1);
INSERT INTO schools (id, name, location, isActive) VALUES (33, 'MAKERERE UNIVERSITY JINJA CAMPUS', 'Jinja', 1);
INSERT INTO schools (id, name, location, isActive) VALUES (34, 'MBALE SCHOOL FOR THE DEAF', 'Mbale', 1);
INSERT INTO schools (id, name, location, isActive) VALUES (35, 'MBALE SCHOOL FOR THE DEAF - HAIRDRESSING', 'Mbale', 1);
INSERT INTO schools (id, name, location, isActive) VALUES (36, 'MBARARA UNIVERSITY SCIENCE AND TECHNOLOGY', 'Mbarara', 1);
INSERT INTO schools (id, name, location, isActive) VALUES (37, 'MITYANA STANDARD SECONDARY SCHOOL', 'Gagavu', 1);
INSERT INTO schools (id, name, location, isActive) VALUES (38, 'MORULEM BOYS PRIMARY SCHOOL', 'Morulem', 1);
INSERT INTO schools (id, name, location, isActive) VALUES (39, 'MORULEM GIRLS PRIMARY SCHOOL', 'Morulem', 1);
INSERT INTO schools (id, name, location, isActive) VALUES (40, 'MORULEM GIRLS SECONDARY SCHOOL', 'Morulem', 1);
INSERT INTO schools (id, name, location, isActive) VALUES (41, 'NALAKAS PRIMARY SCHOOL', 'Nalakas', 1);
INSERT INTO schools (id, name, location, isActive) VALUES (42, 'NILE VOCATIONAL INSTITUTE', 'Jinja', 1);
INSERT INTO schools (id, name, location, isActive) VALUES (43, 'NSAMIZI TRAINING INSTITUTE OF SOCIAL DEVELOPMENT', 'Uganda', 1);
INSERT INTO schools (id, name, location, isActive) VALUES (44, 'NYAKWAE SEED SECONDARY SCHOOL', 'Nyakwae', 1);
INSERT INTO schools (id, name, location, isActive) VALUES (45, 'OBOLOKOME PRIMARY SCHOOL', 'Obolokome', 1);
INSERT INTO schools (id, name, location, isActive) VALUES (46, 'OJWINA PRIMARY SCHOOL', 'Ojwina', 1);
INSERT INTO schools (id, name, location, isActive) VALUES (47, 'ORETA PRIMARY SCHOOL', 'Oreta', 1);
INSERT INTO schools (id, name, location, isActive) VALUES (48, 'POPE JOHN PAUL II MEMORIAL SECONDARY SCHOOL', 'Uganda', 1);
INSERT INTO schools (id, name, location, isActive) VALUES (49, 'RACHKOKO PRIMARY SCHOOL', 'Rachkoko', 1);
INSERT INTO schools (id, name, location, isActive) VALUES (50, 'SISTO MAZZOLDI NURSERY AND PRIMARY SCHOOL', 'Uganda', 1);
INSERT INTO schools (id, name, location, isActive) VALUES (51, 'SOROTI TRAINING INSTITUTE', 'Soroti', 1);
INSERT INTO schools (id, name, location, isActive) VALUES (52, 'SOROTI UNIVERSITY', 'Soroti', 1);
INSERT INTO schools (id, name, location, isActive) VALUES (53, 'ST ANDREW''S SECONDARY SCHOOL', 'Obalanga', 1);
INSERT INTO schools (id, name, location, isActive) VALUES (54, 'ST. DANIEL COMBONI PRIMARY SCHOOL', 'Uganda', 1);
INSERT INTO schools (id, name, location, isActive) VALUES (55, 'ST. KATHERINE SENIOR SECONDARY SCHOOL', 'Lira', 1);
INSERT INTO schools (id, name, location, isActive) VALUES (56, 'ST. KIZITO NURSERY AND PRIMARY SCHOOL', 'Amul', 1);
INSERT INTO schools (id, name, location, isActive) VALUES (57, 'ST. KIZITO PRIMARY SCHOOL', 'Amul', 1);
INSERT INTO schools (id, name, location, isActive) VALUES (58, 'ST. MARY''S COLLEGE ABOKE', 'Aboke', 1);
INSERT INTO schools (id, name, location, isActive) VALUES (59, 'ST. MARY''S NURSERY AND PRIMARY SCHOOL', 'Uganda', 1);
INSERT INTO schools (id, name, location, isActive) VALUES (60, 'ST. MARY''S SEMINARY', 'Nadiket', 1);
INSERT INTO schools (id, name, location, isActive) VALUES (61, 'ST. PETER AND PAUL PRIMARY SCHOOL', 'Achukudu', 1);
INSERT INTO schools (id, name, location, isActive) VALUES (62, 'ST. PHILOMENA JUNIOR', 'Uganda', 1);
INSERT INTO schools (id, name, location, isActive) VALUES (63, 'ST. THERESA NURSERY', 'Uganda', 1);
INSERT INTO schools (id, name, location, isActive) VALUES (64, 'STARLIGHT NURSERY SCHOOL', 'Uganda', 1);
INSERT INTO schools (id, name, location, isActive) VALUES (65, 'TOTO MARIA VOCATIONAL TRAINING CENTER', 'Uganda', 1);
INSERT INTO schools (id, name, location, isActive) VALUES (66, 'YMCA WANDEGEYA', 'Wandegeya', 1);
INSERT INTO schools (id, name, location, isActive) VALUES (67, 'ST. GRACIOUS S S LIRA', 'Lira', 1);

CREATE TABLE "sponsors" (
    "id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
    "fullName" TEXT NOT NULL,
    "contact" TEXT NOT NULL,
    "proxyId" INTEGER,
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" DATETIME NOT NULL, email TEXT, phone TEXT,
    CONSTRAINT "sponsors_proxyId_fkey" FOREIGN KEY ("proxyId") REFERENCES "proxies" ("id") ON DELETE SET NULL ON UPDATE CASCADE
);

INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (47, 'LIDIJA ČILIĆ BURUŠIĆ', '+385912028201', NULL, '2025-08-05T06:27:23.185+00:00', '2025-08-05T06:27:23.185+00:00', NULL, NULL);
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (48, 'JOSIP ERJAVAC', '+385989768295', NULL, '2025-08-05T06:31:08.289+00:00', '2025-08-05T06:31:08.289+00:00', NULL, NULL);
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (49, 'FRANE PROFACA', '+385958223407', NULL, '2025-08-05T06:35:10.499+00:00', '2025-08-05T06:35:10.499+00:00', NULL, NULL);
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (50, 'PRIEST ILIJA ORKIĆ', '+38763342342', NULL, '2025-08-05T06:37:58.643+00:00', '2025-08-05T06:37:58.643+00:00', NULL, NULL);
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (51, 'ŠIME ŠKILJIĆ', '+385917906803', NULL, '2025-08-05T06:40:38.522+00:00', '2025-08-05T06:40:38.522+00:00', NULL, NULL);
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (52, 'PRIEST DEJAN BUBALO', 'dbubalo@net.hr', NULL, '2025-08-05T06:43:42.844+00:00', '2025-08-05T06:43:42.844+00:00', NULL, NULL);
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (53, 'MARIO DRAGUN', '-', 4, '2025-08-05T06:46:09.766+00:00', '2025-08-05T06:46:09.766+00:00', NULL, NULL);
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (54, 'DEJAN ALEKSIĆ', '+385993536201', NULL, '2025-08-05T06:48:39.230+00:00', '2025-08-05T06:48:39.230+00:00', NULL, NULL);
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (55, 'ILIJA HORVAT', '', 4, '2025-08-05T06:52:47.834+00:00', '2025-08-05T06:52:47.834+00:00', NULL, NULL);
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (56, 'ANTEA (OBITELJ PEDIĆ)', '', NULL, '2025-08-05T06:56:22.623+00:00', '2025-08-05T06:56:22.623+00:00', NULL, '+385994159823');
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (57, 'RUŽICA JUKIĆ EZGETA', '', NULL, '2025-08-05T07:01:12.589+00:00', '2025-08-05T07:01:12.589+00:00', NULL, '+38761176290');
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (58, 'TANJA ABRAMUŠIĆ', '', NULL, '2025-08-05T07:02:14.401+00:00', '2025-08-05T07:02:14.401+00:00', NULL, '+38763352071');
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (59, 'ILIJA MARKOVIĆ', '', NULL, '2025-08-05T07:02:32.368+00:00', '2025-08-05T07:02:32.368+00:00', NULL, '+38763009108');
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (60, 'PRIEST PAVO BRAJINOVIĆ', 'FACEBOOK', NULL, '2025-08-05T07:03:05.839+00:00', '2025-08-05T07:03:05.839+00:00', NULL, NULL);
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (61, 'DALIBOR BLEK (MARIO)', '', NULL, '2025-08-05T07:06:29.437+00:00', '2025-08-05T07:06:29.437+00:00', NULL, '+38763144481');
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (62, 'DALIBOR BLEK (LJUBNA)', '', NULL, '2025-08-05T07:08:29.742+00:00', '2025-08-05T07:08:29.742+00:00', NULL, '+38763144481');
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (63, 'RODITELJI POKOJNOG VABECA', '', 5, '2025-08-05T07:14:27.952+00:00', '2025-08-05T07:14:27.952+00:00', NULL, '-');
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (64, 'KATA KOKANOVIĆ', '', 6, '2025-08-05T07:15:26.174+00:00', '2025-08-05T07:15:26.174+00:00', NULL, '-');
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (65, 'NATAŠA MALEŠEVIĆ', '', 6, '2025-08-05T07:15:49.357+00:00', '2025-08-05T07:15:49.357+00:00', NULL, '-');
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (66, 'DIJANA MENDELSKI', '', 6, '2025-08-05T07:16:09.437+00:00', '2025-08-05T07:16:09.437+00:00', NULL, '-');
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (67, 'RUŽA ČALUŠIĆ', '', 6, '2025-08-05T07:17:58.572+00:00', '2025-08-05T07:17:58.572+00:00', NULL, '-');
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (68, 'ZVONIMIRA MICHIELI TOMIĆ', '', 7, '2025-08-05T07:19:20.208+00:00', '2025-08-05T07:19:20.208+00:00', NULL, '-');
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (69, 'RAJNA ZUBČIĆ', '', NULL, '2025-08-05T07:19:45.353+00:00', '2025-08-05T07:19:45.353+00:00', NULL, '+385911877087');
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (70, 'ANĐELKO KRALJ', '', 4, '2025-08-05T07:22:24.788+00:00', '2025-08-05T07:22:24.788+00:00', NULL, '-');
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (71, 'LUCA ČAVKA', '', NULL, '2025-08-05T07:22:49.288+00:00', '2025-08-05T07:22:49.288+00:00', NULL, '+61423640709');
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (72, 'MARIJA I MATAN SAMARDŽIĆ', '', 8, '2025-08-05T07:23:44.183+00:00', '2025-08-05T07:23:44.183+00:00', NULL, '-');
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (73, 'CHOIR "JOHOSEF"', '', NULL, '2025-08-05T07:24:27.342+00:00', '2025-08-05T07:24:27.342+00:00', NULL, '+385998282282');
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (74, 'IVANA RADOŠ', '', NULL, '2025-08-05T07:24:45.672+00:00', '2025-08-05T07:24:45.672+00:00', NULL, '+385992104585');
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (75, 'VLADIMIR BRKULJ', '', NULL, '2025-08-05T07:25:07.174+00:00', '2025-08-05T07:25:07.174+00:00', NULL, '+385959005585');
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (76, 'ANA KOLOPER', '', NULL, '2025-08-05T07:25:23.664+00:00', '2025-08-05T07:25:23.664+00:00', NULL, '+385981831584');
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (77, 'PRIEST SIMO MARŠIĆ', '', 8, '2025-08-05T07:26:26.185+00:00', '2025-08-05T07:26:26.185+00:00', NULL, '-');
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (78, 'HRNKAS MARICA', '', 8, '2025-08-05T07:26:40.045+00:00', '2025-08-05T07:26:40.045+00:00', NULL, '-');
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (79, 'RUŽA ANTUNOVIĆ', '', 8, '2025-08-05T07:26:59.561+00:00', '2025-08-05T07:26:59.561+00:00', NULL, '-');
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (80, 'JOSIPA JURKOVIĆ', '', NULL, '2025-08-05T07:27:16.363+00:00', '2025-08-05T07:27:16.363+00:00', NULL, '+385911827072');
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (81, 'DORA RAGUŽ', '', NULL, '2025-08-05T07:27:43.864+00:00', '2025-08-05T07:27:43.864+00:00', 'dora.raguz2106@gmail.com', NULL);
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (82, 'PEJO JANJIĆ', '', NULL, '2025-08-05T07:28:02.385+00:00', '2025-08-05T07:28:02.385+00:00', NULL, '+38763941047');
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (83, 'STJEPAN MARIJANČIĆ', '', 8, '2025-08-05T07:28:21.982+00:00', '2025-08-05T07:28:21.982+00:00', NULL, '-');
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (84, 'PRIEST LUKANOVIĆ', '', NULL, '2025-08-05T07:29:01.074+00:00', '2025-08-05T07:29:01.074+00:00', NULL, '+38763382026');
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (85, 'DRAGAN ČABRAJA', '', 6, '2025-08-05T07:29:18.176+00:00', '2025-08-05T07:29:18.176+00:00', NULL, '-');
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (86, 'IVANA KALAICA', '', 4, '2025-08-05T07:29:35.122+00:00', '2025-08-05T07:29:35.122+00:00', NULL, '-');
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (87, 'DARKO JURIĆ', '', NULL, '2025-08-05T07:30:03.572+00:00', '2025-08-05T07:30:03.572+00:00', NULL, '+385989330505');
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (88, 'MELODY PAVLETIĆ ESTER', 'https://www.facebook.com/ester.melody', NULL, '2025-08-05T07:30:46.703+00:00', '2025-08-05T07:30:46.703+00:00', NULL, NULL);
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (89, 'LUKA ĆOSIĆ', '', NULL, '2025-08-05T07:32:52.203+00:00', '2025-08-05T07:32:52.203+00:00', 'lux.cosic@gmail.com', '+385911288889');
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (90, 'MATEJ ŠIMIĆ', '', 6, '2025-08-05T07:33:15.266+00:00', '2025-08-05T07:33:15.266+00:00', NULL, '-');
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (91, 'ANTONIO I ANAMARIJA TOLIĆ', '', 6, '2025-08-05T07:33:34.982+00:00', '2025-08-05T07:33:34.982+00:00', NULL, '-');
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (92, 'IVANKA KOŽUL', '', 6, '2025-08-05T07:33:49.243+00:00', '2025-08-05T07:33:49.243+00:00', NULL, '-');
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (93, 'JOSIP DUBAC', '', 6, '2025-08-05T07:34:01.657+00:00', '2025-08-05T07:34:01.657+00:00', NULL, '-');
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (94, 'IVAN TOPALOVIĆ', '', 6, '2025-08-05T07:34:12.938+00:00', '2025-08-05T07:34:12.938+00:00', NULL, NULL);
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (95, 'MARINKO MIKULIĆ', '', 6, '2025-08-05T07:34:27.030+00:00', '2025-08-05T07:34:27.030+00:00', NULL, NULL);
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (96, 'FR. TOMICA BOŽIČEK', '', NULL, '2025-08-05T07:34:54.351+00:00', '2025-08-05T07:34:54.351+00:00', NULL, '+38598810901');
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (97, 'IVANK I ŽELJKO BOBANOVIĆ', '', 7, '2025-08-05T07:35:13.370+00:00', '2025-08-05T07:35:13.370+00:00', NULL, NULL);
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (98, 'IVICA MARTIĆ', '', NULL, '2025-08-05T07:35:31.953+00:00', '2025-08-05T07:35:31.953+00:00', NULL, '+38761464244');
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (99, 'OBITELJ MARKUNOVIĆ', '', NULL, '2025-08-05T07:35:58.403+00:00', '2025-08-05T07:35:58.403+00:00', NULL, '+4367763089249');
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (100, 'JOSIP HRKAČ', '', 6, '2025-08-05T07:36:15.194+00:00', '2025-08-05T07:36:15.194+00:00', NULL, NULL);
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (101, 'KSENIJA KOŽUL', '', 6, '2025-08-05T07:36:30.928+00:00', '2025-08-05T07:36:30.928+00:00', NULL, NULL);
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (102, 'ZVONKO BOSANKIĆ (BRČKO)', '', NULL, '2025-08-05T07:37:09.671+00:00', '2025-08-05T07:37:09.671+00:00', NULL, '+4368110410902');
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (103, 'AMELINA I ADAM ABEL', '', 9, '2025-08-05T07:38:33.197+00:00', '2025-08-05T07:38:33.197+00:00', NULL, NULL);
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (104, 'ANTO UDOVČIĆ', '', NULL, '2025-08-05T07:38:55.162+00:00', '2025-08-05T07:38:55.162+00:00', NULL, '+38763523603');
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (105, 'JOSIP VIDAKOVIĆ', '', 6, '2025-08-05T07:39:15.486+00:00', '2025-08-05T07:39:15.486+00:00', NULL, NULL);
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (106, 'ANDREJA BOBAN', '', NULL, '2025-08-05T07:39:37.603+00:00', '2025-08-05T07:39:37.603+00:00', NULL, '+38598480765');
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (107, 'MARIJAN TUNIĆ', '', 10, '2025-08-05T07:40:08.839+00:00', '2025-08-05T07:40:08.839+00:00', NULL, NULL);
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (108, 'KATA ŠIMIĆ', '', NULL, '2025-08-05T07:40:33.734+00:00', '2025-08-05T07:40:33.734+00:00', NULL, '+491773238843');
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (109, 'SNJEŽANA KNEŽEVIĆ', '', NULL, '2025-08-05T07:41:04.743+00:00', '2025-08-05T07:41:04.743+00:00', NULL, '+385915901599');
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (110, 'MARIJANA MAZALOVIĆ', '', NULL, '2025-08-05T07:41:27.512+00:00', '2025-08-05T07:41:27.512+00:00', NULL, '+385989157712');
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (111, 'ŠIME BUHA', '', NULL, '2025-08-05T07:42:39.217+00:00', '2025-08-05T07:42:39.217+00:00', NULL, '+385997995385');
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (112, 'MARA DUGEC', '', NULL, '2025-08-05T07:42:57.015+00:00', '2025-08-05T07:42:57.015+00:00', NULL, '+385919701207');
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (113, 'JOSIP PEKAS', '', NULL, '2025-08-05T07:43:21.903+00:00', '2025-08-05T07:43:21.903+00:00', NULL, '+385955766857');
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (114, 'ANA CVITKUŠIĆ', '', NULL, '2025-08-05T07:43:40.449+00:00', '2025-08-05T07:43:40.449+00:00', NULL, '+4369917082325');
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (115, 'ANTE BUHA', '', NULL, '2025-08-05T07:43:59.872+00:00', '2025-08-05T07:43:59.872+00:00', NULL, '+385996979696');
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (116, 'SLAVICA', '', NULL, '2025-08-05T07:44:19.084+00:00', '2025-08-05T07:44:19.084+00:00', NULL, '+385921689987');
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (117, 'ZDENKO BIČVIĆ', '', 11, '2025-08-05T07:44:57.321+00:00', '2025-08-05T07:44:57.321+00:00', NULL, NULL);
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (118, 'GORDANA TARAS', '', NULL, '2025-08-05T07:45:27.932+00:00', '2025-08-05T07:45:27.932+00:00', NULL, '+385959002804');
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (119, 'DARKO JURIĆ', '', NULL, '2025-08-05T07:45:48.423+00:00', '2025-08-05T07:45:48.423+00:00', NULL, '+385989330505');
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (120, 'IVANA HENDIJA', '', NULL, '2025-08-05T07:46:50.489+00:00', '2025-08-05T07:46:50.489+00:00', NULL, '+385917318952');
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (121, 'TOMISLAV GAŠPAR', '', NULL, '2025-08-05T07:47:09.172+00:00', '2025-08-05T07:47:09.172+00:00', NULL, '+385922983319');
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (122, 'ANTUN KOVAČEVIĆ', '', 4, '2025-08-05T07:47:22.893+00:00', '2025-08-05T07:47:22.893+00:00', NULL, NULL);
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (123, 'BRANKO IVAN PERVAN', 'https://www.facebook.com/brankoivan.pervan.3', NULL, '2025-08-05T07:47:56.583+00:00', '2025-08-05T07:47:56.583+00:00', NULL, NULL);
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (124, 'LUKA PEKAS', '', NULL, '2025-08-05T07:48:13.155+00:00', '2025-08-05T07:48:13.155+00:00', NULL, '+385958762051');
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (125, 'IVAN KOPIĆ (PRIEST GORICA)', '', NULL, '2025-08-05T07:48:32.043+00:00', '2025-08-05T07:48:32.043+00:00', NULL, '+38763162182');
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (126, 'ANKA', '', NULL, '2025-08-05T07:48:49.785+00:00', '2025-08-05T07:48:49.785+00:00', NULL, '+385995006077');
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (127, 'ANA MARIJA VIDAKOVIĆ', '', 6, '2025-08-05T07:49:11.511+00:00', '2025-08-05T07:49:11.511+00:00', NULL, NULL);
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (128, 'BRUNO I GORDANA', '', NULL, '2025-08-05T07:49:39.263+00:00', '2025-08-05T07:49:39.263+00:00', NULL, '+38761783834');
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (129, 'HELENA DEZEN', '', 4, '2025-08-05T07:49:57.278+00:00', '2025-08-05T07:49:57.278+00:00', NULL, NULL);
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (130, 'KATARINA SKENDEROVIĆ', '', NULL, '2025-08-05T07:50:22.963+00:00', '2025-08-05T07:50:22.963+00:00', NULL, '+385989947284');
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (131, 'IVANA KALAICA', '', NULL, '2025-08-05T07:51:45.603+00:00', '2025-08-05T07:51:45.603+00:00', NULL, '+38598428275');
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (132, 'TANJA ABRAMUŠIĆ', '', NULL, '2025-08-05T07:52:19.486+00:00', '2025-08-05T07:52:19.486+00:00', NULL, '+38763352071');
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (133, 'HRVOJE PEKAS', '', NULL, '2025-08-05T07:55:59.353+00:00', '2025-08-05T07:55:59.353+00:00', NULL, '+385959099100');
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (134, 'IVANA PEKAS', '', NULL, '2025-08-05T07:58:15.183+00:00', '2025-08-05T07:58:15.183+00:00', NULL, '+385912539765');
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (135, 'LJILJA MARKOC', '', NULL, '2025-08-05T07:59:08.183+00:00', '2025-08-05T07:59:08.183+00:00', 'ljiljamrkoc1501@gmail.com', NULL);
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (136, 'OBITELJ RAVNJAK', '', NULL, '2025-08-05T07:59:27.662+00:00', '2025-08-05T07:59:27.662+00:00', NULL, '+38763424242');
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (137, 'DIJANA LACIJC ZAKUCAC', '', NULL, '2025-08-05T08:03:00.992+00:00', '2025-08-05T08:03:00.992+00:00', NULL, '+385914611530');
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (138, 'DRAŽEN BEKAVAC', '', 12, '2025-08-05T08:04:20.629+00:00', '2025-08-05T08:04:20.629+00:00', NULL, NULL);
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (139, 'JAKOV BRDARIĆ', '', 6, '2025-08-05T08:04:46.724+00:00', '2025-08-05T08:04:46.724+00:00', NULL, NULL);
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (140, 'IVAN KOVAČEVIĆ', '', 4, '2025-08-05T08:05:05.208+00:00', '2025-08-05T08:05:05.208+00:00', NULL, NULL);
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (141, 'CECILIJA SKENDEROVIĆ', '', 13, '2025-08-05T08:05:53.747+00:00', '2025-08-05T08:05:53.747+00:00', NULL, NULL);
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (142, 'DOMINIK ŠIMIĆ', '', 6, '2025-08-05T08:06:10.555+00:00', '2025-08-05T08:06:10.555+00:00', NULL, NULL);
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (143, 'DAMIR BENČEVIĆ', '', 4, '2025-08-05T08:06:30.351+00:00', '2025-08-05T08:06:30.351+00:00', NULL, NULL);
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (144, 'KARLO KRIŽANOVIĆ', '', NULL, '2025-08-05T08:06:50.531+00:00', '2025-08-05T08:06:50.531+00:00', NULL, '+38598685266');
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (145, 'ŽELJKO LUKADINOVIĆ', '', 4, '2025-08-05T08:07:14.258+00:00', '2025-08-05T08:07:14.258+00:00', NULL, NULL);
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (146, 'DORA RAGUŽ (VLAHO)', 'FB', NULL, '2025-08-05T08:09:17.947+00:00', '2025-08-05T08:09:17.947+00:00', 'dora.raguz2106@gmail.com', NULL);
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (147, 'NIKOLINA ŠTIMAC', 'FB', NULL, '2025-08-05T08:10:00.904+00:00', '2025-08-05T08:10:00.904+00:00', NULL, NULL);
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (148, 'DANIJELA RADAS ABRAMOVIĆ', '', 7, '2025-08-05T08:10:52.239+00:00', '2025-08-05T08:10:52.239+00:00', NULL, NULL);
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (149, 'SREĆKO TOMASOVIĆ (OMIŠ)', '', NULL, '2025-08-05T08:16:32.491+00:00', '2025-08-05T08:16:32.491+00:00', NULL, '+385959057979');
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (150, 'ANAMARIJA (RADIO MEĐUGORJE)', '', NULL, '2025-08-05T08:16:57.819+00:00', '2025-08-05T08:16:57.819+00:00', NULL, '+38763440180');
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (151, 'ANĐELKA MOSTARKIĆ', '', 6, '2025-08-05T08:17:19.173+00:00', '2025-08-05T08:17:19.173+00:00', NULL, NULL);
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (152, 'MARIJANA ZOVKO HRASTUŠA', '', NULL, '2025-08-05T08:18:14.679+00:00', '2025-08-05T08:18:14.679+00:00', NULL, '+38763860732');
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (153, 'IVAN I ZRINKA ROGALO', '', NULL, '2025-08-05T08:18:36.381+00:00', '2025-08-05T08:18:36.381+00:00', NULL, '+385989178433');
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (154, 'VESNA BENČEVIĆ', '', 4, '2025-08-05T08:18:52.891+00:00', '2025-08-05T08:18:52.891+00:00', NULL, NULL);
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (155, 'DAMIR BUTKOVIĆ', '', 4, '2025-08-05T08:19:10.065+00:00', '2025-08-05T08:19:10.065+00:00', NULL, NULL);
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (156, 'MARINA FILIĆ', '', NULL, '2025-08-05T08:19:34.328+00:00', '2025-08-05T08:19:34.328+00:00', NULL, '+385989357813');
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (157, 'MARINKA RADOŠ PAPRATNICA', '', NULL, '2025-08-05T08:19:58.522+00:00', '2025-08-05T08:19:58.522+00:00', NULL, '+38763788707');
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (158, 'DRAGICA RADMAN', '', 6, '2025-08-05T09:12:08.161+00:00', '2025-08-05T09:12:08.161+00:00', NULL, NULL);
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (159, 'RUŽA VRHOVČEVIĆ', '', 6, '2025-08-05T09:12:26.450+00:00', '2025-08-05T09:12:26.450+00:00', NULL, NULL);
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (160, 'IVANA VRHOVČEVIĆ', '', 6, '2025-08-05T09:12:41.297+00:00', '2025-08-05T09:12:41.297+00:00', NULL, NULL);
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (161, 'MAJA VRHOVČEVIĆ', '', 6, '2025-08-05T09:12:53.897+00:00', '2025-08-05T09:12:53.897+00:00', NULL, NULL);
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (162, 'ROBERT KOŽUL', '', 6, '2025-08-05T09:13:06.264+00:00', '2025-08-05T09:13:06.264+00:00', NULL, NULL);
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (163, 'ANĐA TOLIĆ', '', 6, '2025-08-05T09:13:21.262+00:00', '2025-08-05T09:13:21.262+00:00', NULL, NULL);
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (164, 'ANĐELKA I PAVAO SAMARDŽIĆ', '', 8, '2025-08-05T09:13:36.362+00:00', '2025-08-05T09:13:36.362+00:00', NULL, NULL);
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (165, 'MATEJ PAVIĆ', '', NULL, '2025-08-05T09:13:53.883+00:00', '2025-08-05T09:13:53.883+00:00', 'matejpavic@gmail.com', NULL);
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (166, 'JURE ŠESTAN', '', NULL, '2025-08-05T09:14:12.934+00:00', '2025-08-05T09:14:12.934+00:00', NULL, '+385955076014');
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (167, 'JOSIP PUČIĆ', '', NULL, '2025-08-05T09:14:45.952+00:00', '2025-08-05T09:14:45.952+00:00', NULL, '+385995028061');
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (168, 'MARIO UDOVIČIĆ', '', NULL, '2025-08-05T09:15:36.114+00:00', '2025-08-05T09:15:36.114+00:00', 'mario.udovicici@gmail.com', NULL);
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (169, 'MATILDA MLADIN (OMIŠ)', '', NULL, '2025-08-05T09:17:45.280+00:00', '2025-08-05T09:17:45.280+00:00', 'mmladin276@gmail.com', NULL);
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (170, 'KATARINA MATANOVIĆ', '', 4, '2025-08-05T09:18:06.078+00:00', '2025-08-05T09:18:06.078+00:00', NULL, NULL);
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (171, 'OBITELJ JURIŠIĆ', '', NULL, '2025-08-05T09:18:54.668+00:00', '2025-08-05T09:18:54.668+00:00', NULL, '+38763866300');
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (172, 'DAVOR ADŽIĆ', '', 4, '2025-08-05T09:19:18.033+00:00', '2025-08-05T09:19:18.033+00:00', NULL, NULL);
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (173, 'PERO MARIĆ (SESTRA)', '', NULL, '2025-08-05T09:19:56.164+00:00', '2025-08-05T09:19:56.164+00:00', 'peromaricessen@gmail.com', NULL);
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (174, 'PERO MARIĆ', '', NULL, '2025-08-05T09:20:18.773+00:00', '2025-08-05T09:20:18.773+00:00', 'peromaricessen@gmail.com', NULL);
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (175, 'MARIJA GABRIĆ', '', NULL, '2025-08-05T09:20:47.556+00:00', '2025-08-05T09:20:47.556+00:00', NULL, '+385981655305');
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (176, 'JOSIP DUILO', '', NULL, '2025-08-05T09:21:12.973+00:00', '2025-08-05T09:21:12.973+00:00', NULL, '+38598652542');
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (177, 'ANA TADIĆ', '', NULL, '2025-08-05T09:21:51.343+00:00', '2025-08-05T09:21:51.343+00:00', NULL, '+385914533530');
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (178, 'MIROSLAV REZO', '', 4, '2025-08-05T09:22:05.565+00:00', '2025-08-05T09:22:05.565+00:00', NULL, NULL);
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (179, 'LJILJANA ANDRIĆ', '', NULL, '2025-08-05T09:22:28.814+00:00', '2025-08-05T09:22:28.814+00:00', NULL, '+491722886883');
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (180, 'PARSHIONER (PRIEST VJEKOSLAV)', '', NULL, '2025-08-05T09:24:18.181+00:00', '2025-08-05T09:24:18.181+00:00', NULL, '+385993554383');
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (181, 'FRANJO TOMIĆ', 'FB', NULL, '2025-08-05T09:24:43.394+00:00', '2025-08-05T09:24:43.394+00:00', NULL, '+38763465338');
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (182, 'PRIEST PAVO COUSIN', '', 8, '2025-08-05T09:26:30.087+00:00', '2025-08-05T09:26:30.087+00:00', NULL, NULL);
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (183, 'JOSIP I BARICA RAZEK', '', 6, '2025-08-05T09:26:47.823+00:00', '2025-08-05T09:26:47.823+00:00', NULL, NULL);
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (184, 'GORDANA ČARAPOVIĆ', '', 6, '2025-08-05T09:27:08.685+00:00', '2025-08-05T09:27:08.685+00:00', NULL, NULL);
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (185, 'ŽELJKA BOKAN SOLDATIĆ', '', NULL, '2025-08-05T09:27:29.225+00:00', '2025-08-05T09:27:29.225+00:00', NULL, '+385992493662');
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (186, 'OBITELJ NIMČEVIĆ', '', NULL, '2025-08-05T09:28:01.626+00:00', '2025-08-05T09:28:01.626+00:00', 'gnimcevic@gmail.com', NULL);
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (187, 'ANĐELKA I PAVAO KOVAČEVIĆ', '', 8, '2025-08-05T09:28:23.728+00:00', '2025-08-05T09:28:23.728+00:00', NULL, NULL);
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (188, 'SLAVKA PANCIROV', '', NULL, '2025-08-05T09:29:14.362+00:00', '2025-08-05T09:29:14.362+00:00', NULL, '+385915331777');
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (189, 'ŠOŠIĆ MIRA', '', 8, '2025-08-05T09:29:34.681+00:00', '2025-08-05T09:29:34.681+00:00', NULL, NULL);
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (190, 'MATO I MARIJA JURIĆ', '', 8, '2025-08-05T09:29:49.906+00:00', '2025-08-05T09:29:49.906+00:00', NULL, NULL);
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (191, 'LJILJANA I DARKO MICANOVIĆ', '', NULL, '2025-08-05T09:30:12.736+00:00', '2025-08-05T09:30:12.736+00:00', NULL, '+4369917308259');
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (192, 'MATEJ MIHALJEVIĆ', '', NULL, '2025-08-05T09:30:30.222+00:00', '2025-08-05T09:30:30.222+00:00', NULL, '+385996386623');
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (193, 'TOMISLAV MADŽAR', '', NULL, '2025-08-05T09:31:00.725+00:00', '2025-08-05T09:31:00.725+00:00', 'tomislavma8@gmail.com', NULL);
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (194, 'STJEPAN LUKADINOVIĆ', '', 4, '2025-08-05T09:31:16.118+00:00', '2025-08-05T09:31:16.118+00:00', NULL, NULL);
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (195, 'IVAN KOLAREVIĆ', '', 4, '2025-08-05T09:31:28.583+00:00', '2025-08-05T09:31:28.583+00:00', NULL, NULL);
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (196, 'SLAVEN MILA', '', 4, '2025-08-05T09:31:40.195+00:00', '2025-08-05T09:31:40.195+00:00', NULL, NULL);
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (197, 'DAMIR KOVAČEVIĆ', '', 4, '2025-08-05T09:31:55.431+00:00', '2025-08-05T09:31:55.431+00:00', NULL, NULL);
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (198, 'VALERIJA KOVAČEVIĆ', '', 4, '2025-08-05T09:32:05.957+00:00', '2025-08-05T09:32:05.957+00:00', NULL, NULL);
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (199, 'MARTA JELIĆ', '', NULL, '2025-08-05T09:32:24.003+00:00', '2025-08-05T09:32:24.003+00:00', NULL, '+385958549778');
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (200, 'SARA PASTOR MILJANIĆ I ŠIMUN REZO', '', 4, '2025-08-05T09:32:44.268+00:00', '2025-08-05T09:32:44.268+00:00', NULL, NULL);
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (201, 'SLAVEN LUKADINOVIĆ', '', 4, '2025-08-05T09:33:06.392+00:00', '2025-08-05T09:33:06.392+00:00', NULL, NULL);
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (202, 'ŽELJKO PASKOVIĆ', 'FB', NULL, '2025-08-05T09:36:07.941+00:00', '2025-08-05T09:36:07.941+00:00', NULL, NULL);
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (203, 'MARTA BARIŠIĆ', 'FB', NULL, '2025-08-05T09:36:48.611+00:00', '2025-08-05T09:36:48.611+00:00', NULL, NULL);
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (204, 'ANTO ZUBAK (ŽENA)', 'FB', NULL, '2025-08-05T09:37:46.098+00:00', '2025-08-05T09:37:46.098+00:00', NULL, NULL);
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (205, 'JELENA MATESIĆ', '', NULL, '2025-08-05T09:38:15.645+00:00', '2025-08-05T09:38:15.645+00:00', NULL, '+385921186642');
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (206, 'SISTER ANA', '', NULL, '2025-08-05T09:38:34.089+00:00', '2025-08-05T09:38:34.089+00:00', NULL, '+4917678579619');
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (207, 'PRIEST VJEKOSLAV', '', NULL, '2025-08-05T09:39:22.319+00:00', '2025-08-05T09:39:22.319+00:00', NULL, '+385993554383');
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (208, 'VALSIM NITRAM CICADNA', '', NULL, '2025-08-05T09:39:42.039+00:00', '2025-08-05T09:39:42.039+00:00', NULL, '+38763517220');
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (209, 'MARIJA IVIĆ', '', 6, '2025-08-05T09:39:54.196+00:00', '2025-08-05T09:39:54.196+00:00', NULL, NULL);
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (210, 'LUCA RATKOVIĆ', '', 6, '2025-08-05T09:40:14.421+00:00', '2025-08-05T09:40:14.421+00:00', NULL, NULL);
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (211, 'NADA LUKANOVIĆ', '', 9, '2025-08-05T09:40:29.908+00:00', '2025-08-05T09:40:29.908+00:00', NULL, NULL);
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (212, 'DRAGANA I VJEKOSALV JOKIĆ', '', 9, '2025-08-05T09:40:45.452+00:00', '2025-08-05T09:40:45.452+00:00', NULL, NULL);
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (213, 'ANA MARKULIN', 'FB', NULL, '2025-08-05T09:41:06.657+00:00', '2025-08-05T09:41:06.657+00:00', NULL, NULL);
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (214, 'RUŽA SELIMOVIĆ', '', NULL, '2025-08-05T09:41:33.603+00:00', '2025-08-05T09:41:33.603+00:00', 'ruza.mandic2303@gmail.com', NULL);
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (215, 'BLAŽENKA MATEK (ORAHOVICE)', '', NULL, '2025-08-05T09:41:57.773+00:00', '2025-08-05T09:41:57.773+00:00', NULL, '+38598343995');
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (216, 'DRAGO VIDAKOVIĆ', '', 4, '2025-08-05T09:42:14.272+00:00', '2025-08-05T09:42:14.272+00:00', NULL, NULL);
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (217, 'ANKICA I BLAŽ LUKAC', '', 6, '2025-08-05T09:42:34.830+00:00', '2025-08-05T09:42:34.830+00:00', NULL, NULL);
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (218, 'ILIJA KOVAČEVIĆ', '', 4, '2025-08-05T09:42:56.350+00:00', '2025-08-05T09:42:56.350+00:00', NULL, NULL);
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (219, 'ANTE I MARINA KOVAČEVIĆ', '', 8, '2025-08-05T09:43:46.753+00:00', '2025-08-05T09:43:46.753+00:00', NULL, NULL);
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (220, 'RUŽICA I DANIJEL BANOVAK', '', NULL, '2025-08-05T09:44:15.303+00:00', '2025-08-05T09:44:15.303+00:00', 'ruzicabanovak@gmail.com', NULL);
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (221, 'KATICA JOVANOVAC', '', NULL, '2025-08-05T09:44:39.271+00:00', '2025-08-05T09:44:39.271+00:00', NULL, '+385996368868');
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (222, 'IVONA I ILIJA DRETVIĆ', '', NULL, '2025-08-05T09:44:58.026+00:00', '2025-08-05T09:44:58.026+00:00', NULL, '+385992064321');
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (223, 'ANITA POLIĆ', '', NULL, '2025-08-05T09:45:19.101+00:00', '2025-08-05T09:45:19.101+00:00', NULL, '+38598526829');
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (224, 'ANDREJA KUHARIĆ', '', NULL, '2025-08-05T09:45:48.542+00:00', '2025-08-05T09:45:48.542+00:00', 'kuharicandreja9@gmail.com', NULL);
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (225, 'SLAVICA I STIPAN LUJIĆ', '', 8, '2025-08-05T09:46:04.562+00:00', '2025-08-05T09:46:04.562+00:00', NULL, NULL);
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (226, 'PETAR MARIĆ', '', NULL, '2025-08-05T09:49:01.308+00:00', '2025-08-05T09:49:01.308+00:00', NULL, NULL);
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (227, 'MLADENKA BARIČEVIĆ', '', NULL, '2025-08-05T09:49:21.626+00:00', '2025-08-05T09:49:21.626+00:00', NULL, '+385996669888');
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (228, 'OBITELJ DUGANDŽIĆ', '', NULL, '2025-08-05T09:49:49.800+00:00', '2025-08-05T09:49:49.800+00:00', 'blatnica75@gmail.com', NULL);
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (229, 'JULIŠKA MILA', '', 4, '2025-08-05T09:50:12.760+00:00', '2025-08-05T09:50:12.760+00:00', NULL, NULL);
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (230, 'STJEPAN KNEZOVIĆ', '', 4, '2025-08-05T09:50:27.549+00:00', '2025-08-05T09:50:27.549+00:00', NULL, NULL);
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (231, 'MARIN BELIĆ', '', 4, '2025-08-05T09:50:42.441+00:00', '2025-08-05T09:50:42.441+00:00', NULL, NULL);
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (232, 'IVAN REZO', '', 4, '2025-08-05T09:50:53.648+00:00', '2025-08-05T09:50:53.648+00:00', NULL, NULL);
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (233, 'MARICA LUSTICA', '', NULL, '2025-08-05T09:51:18.842+00:00', '2025-08-05T09:51:18.842+00:00', NULL, '+38598566054');
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (234, 'KLARA (ORAHOVICA)', '', NULL, '2025-08-05T09:51:34.186+00:00', '2025-08-05T09:51:34.186+00:00', NULL, '+385989459598');
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (235, 'DAMIR BARIČEVIĆ', '', NULL, '2025-08-05T09:51:55.308+00:00', '2025-08-05T09:51:55.308+00:00', 'damir.baricevic@gmail.com', NULL);
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (236, 'ETELKA CRNJANSKI', '', 4, '2025-08-05T09:52:08.218+00:00', '2025-08-05T09:52:08.218+00:00', NULL, NULL);
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (237, 'VALENTINA PAPRIKA', '', 4, '2025-08-05T09:52:27.228+00:00', '2025-08-05T09:52:27.228+00:00', NULL, NULL);
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (238, 'LUKA IVAN SECKAR', '', 4, '2025-08-05T09:52:42.689+00:00', '2025-08-05T09:52:42.689+00:00', NULL, NULL);
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (239, 'PETAR MARIĆ', '', 4, '2025-08-05T09:54:21.217+00:00', '2025-08-05T09:54:21.217+00:00', NULL, NULL);
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (240, 'NIKOLINA KRIZELJ RADOŠ', '', NULL, '2025-08-05T09:55:30.438+00:00', '2025-08-05T09:55:30.438+00:00', NULL, '+385989651596');
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (241, 'PETER MARKOVIĆ', 'FB', NULL, '2025-08-05T09:55:59.077+00:00', '2025-08-05T09:55:59.077+00:00', NULL, NULL);
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (242, 'IVAN VUKOJA', '', NULL, '2025-08-05T09:56:15.095+00:00', '2025-08-05T09:56:15.095+00:00', NULL, '+38763144512');
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (243, 'ANA PRENDA LOVRIĆ', '', NULL, '2025-08-05T09:56:37.006+00:00', '2025-08-05T09:56:37.006+00:00', NULL, '+38598618299');
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (244, 'ANA MAMIĆ', 'FB', NULL, '2025-08-05T09:56:46.633+00:00', '2025-08-05T09:56:46.633+00:00', NULL, NULL);
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (245, 'BORIS SOSIC', 'FB', NULL, '2025-08-05T09:57:02.418+00:00', '2025-08-05T09:57:02.418+00:00', NULL, NULL);
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (246, 'MARIJA MATANOVIĆ', 'FB', NULL, '2025-08-05T09:57:13.683+00:00', '2025-08-05T09:57:13.683+00:00', NULL, NULL);
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (247, 'IVAN KNEŽEVIĆ', 'FB', NULL, '2025-08-05T09:57:24.318+00:00', '2025-08-05T09:57:24.318+00:00', NULL, NULL);
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (248, 'MATO JUKIĆ', 'FB', NULL, '2025-08-05T09:57:33.187+00:00', '2025-08-05T09:57:33.187+00:00', NULL, NULL);
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (249, 'ANTO KOVAČEVIĆ', 'FB', NULL, '2025-08-05T09:57:56.786+00:00', '2025-08-05T09:57:56.786+00:00', NULL, NULL);
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (250, 'ANA STIPINA', 'FB', NULL, '2025-08-05T09:58:07.636+00:00', '2025-08-05T09:58:07.636+00:00', NULL, NULL);
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (251, 'MANDA MAJIĆ', 'FB', NULL, '2025-08-05T09:58:17.885+00:00', '2025-08-05T09:58:17.885+00:00', NULL, NULL);
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (252, 'GORAN MANDURA', 'FB', NULL, '2025-08-05T09:58:27.815+00:00', '2025-08-05T09:58:27.815+00:00', NULL, NULL);
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (253, 'MARKO BLEK (LJUBNA)', '', NULL, '2025-08-05T12:44:04.392+00:00', '2025-08-05T12:44:04.392+00:00', NULL, '+38763144481');
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (254, 'DANIJELA KAŠTEL NOVI', '', NULL, '2025-08-05T12:44:38.770+00:00', '2025-08-05T12:44:38.770+00:00', NULL, '+385912357810');
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (255, 'NIKOLINA SIMIĆ', '', NULL, '2025-08-05T12:45:14.091+00:00', '2025-08-05T12:45:14.091+00:00', NULL, '+385921943195');
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (256, 'ANA DRAGOŠEVIĆ (OMIŠ)', '', NULL, '2025-08-05T12:45:40.911+00:00', '2025-08-05T12:45:40.911+00:00', NULL, '+385951396552');
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (257, 'IVANA GRAVIĆ', '', NULL, '2025-08-05T12:45:57.670+00:00', '2025-08-05T12:45:57.670+00:00', NULL, '+385911977214');
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (258, 'KATARINA TADIĆ', '', NULL, '2025-08-05T12:46:19.490+00:00', '2025-08-05T12:46:19.490+00:00', NULL, '+385919010940');
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (259, 'IVANKA JUKIĆ', '', NULL, '2025-08-05T12:46:37.902+00:00', '2025-08-05T12:46:37.902+00:00', NULL, '+385981621031');
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (260, 'MLADENKA (ZADAR)', '', NULL, '2025-08-05T12:47:35.180+00:00', '2025-08-05T12:47:35.180+00:00', NULL, '+385915343787');
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (261, 'ŽARKO (CRKVICE)', '', NULL, '2025-08-05T12:47:57.349+00:00', '2025-08-05T12:47:57.349+00:00', NULL, '+387603002883');
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (262, 'NEVENKA', '', NULL, '2025-08-05T12:48:14.631+00:00', '2025-08-05T12:48:14.631+00:00', NULL, '+385991945447');
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (263, 'DIJANA SEKA TOMIĆ', 'FB', NULL, '2025-08-05T12:48:43.611+00:00', '2025-08-05T12:48:43.611+00:00', NULL, NULL);
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (264, 'SLAVICA (CRKVICE)', '', NULL, '2025-08-05T12:49:03.820+00:00', '2025-08-05T12:49:03.820+00:00', NULL, '+38598555867');
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (265, 'ŠIME KEVRIĆ', '', NULL, '2025-08-05T12:49:18.009+00:00', '2025-08-05T12:49:18.009+00:00', NULL, '+385992374120');
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (266, 'IVICA BAJO', 'FB', NULL, '2025-08-05T12:50:00.889+00:00', '2025-08-05T12:50:00.889+00:00', NULL, NULL);
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (267, 'ŽELJKO TOMIĆ', 'FB', NULL, '2025-08-05T12:50:13.531+00:00', '2025-08-05T12:50:13.531+00:00', NULL, NULL);
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (268, 'BORO NEVISTIĆ', '', 4, '2025-08-05T12:50:23.440+00:00', '2025-08-05T12:50:23.440+00:00', NULL, NULL);
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (269, 'MATE BAJIĆ', '', 4, '2025-08-05T12:50:35.607+00:00', '2025-08-05T12:50:35.607+00:00', NULL, NULL);
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (270, 'LJUBICA PENIĆ', '', NULL, '2025-08-05T12:50:52.248+00:00', '2025-08-05T12:50:52.248+00:00', NULL, '+385915577058');
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (271, 'ANAMARIJA SOLDO', '', 4, '2025-08-05T12:51:08.641+00:00', '2025-08-05T12:51:08.641+00:00', NULL, NULL);
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (272, 'RUDOLF ĆURIĆ', '', 4, '2025-08-05T12:53:25.349+00:00', '2025-08-05T12:53:25.349+00:00', NULL, NULL);
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (273, 'PRIEST PAVO KOPIĆ (KREPISCA)', '', 8, '2025-08-05T12:54:19.645+00:00', '2025-08-05T12:54:19.645+00:00', NULL, NULL);
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (274, 'PRIEST MATO JANJIĆ (POLJACI)', '', 8, '2025-08-05T12:54:34.749+00:00', '2025-08-05T12:54:34.749+00:00', NULL, NULL);
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (275, 'MARICA ALFEDI', '', 6, '2025-08-05T12:54:59.219+00:00', '2025-08-05T12:54:59.219+00:00', NULL, NULL);
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (276, 'JADRANKA BARTULOVIĆ', '', NULL, '2025-08-05T12:55:24.780+00:00', '2025-08-05T12:55:24.780+00:00', NULL, '+385912505957');
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (277, 'EVA VALJETIĆ', '', 6, '2025-08-05T12:55:39.181+00:00', '2025-08-05T12:55:39.181+00:00', NULL, NULL);
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (278, 'LJILJA MIKULIĆ', '', 6, '2025-08-05T12:55:53.709+00:00', '2025-08-05T12:55:53.709+00:00', NULL, NULL);
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (279, 'KATA ŠPEHAR', '', 6, '2025-08-05T12:56:07.365+00:00', '2025-08-05T12:56:07.365+00:00', NULL, NULL);
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (280, 'MARA MILOŠ', '', 6, '2025-08-05T12:56:19.364+00:00', '2025-08-05T12:56:19.364+00:00', NULL, NULL);
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (281, 'ŽELJKO RAŽEK', '', 6, '2025-08-05T12:56:38.451+00:00', '2025-08-05T12:56:38.451+00:00', NULL, NULL);
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (282, 'KATICA ŠIMIĆ', '', 6, '2025-08-05T12:56:52.548+00:00', '2025-08-05T12:56:52.548+00:00', NULL, NULL);
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (283, 'DRAŽEN VIDAKOVIĆ', '', 6, '2025-08-05T12:57:08.256+00:00', '2025-08-05T12:57:08.256+00:00', NULL, NULL);
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (284, 'TOMISLAV VIDAKOVIĆ', '', 6, '2025-08-05T12:57:23.300+00:00', '2025-08-05T12:57:23.300+00:00', NULL, NULL);
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (285, 'ZDENKA ŽUGAJ', '', 6, '2025-08-05T12:57:52.048+00:00', '2025-08-05T12:57:52.048+00:00', NULL, NULL);
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (286, 'ŽELJKO ŠIMIĆ', '', 6, '2025-08-05T12:58:26.525+00:00', '2025-08-05T12:58:26.525+00:00', NULL, NULL);
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (287, 'ANĐA SUŠAC', '', 4, '2025-08-05T13:00:51.744+00:00', '2025-08-05T13:00:51.744+00:00', NULL, NULL);
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (288, 'DARKO TRBARA', 'https://www.facebook.com/darko.trbara', NULL, '2025-08-05T13:01:52.688+00:00', '2025-08-05T13:01:52.688+00:00', NULL, NULL);
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (289, 'ANTONIO MAGDIĆ', '', NULL, '2025-08-05T13:02:21.308+00:00', '2025-08-05T13:02:21.308+00:00', 'antonio@superfluo.hr', NULL);
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (290, 'MARKO PERKOVIĆ', '', 6, '2025-08-05T13:02:40.186+00:00', '2025-08-05T13:02:40.186+00:00', NULL, NULL);
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (291, 'BOŽICA KOLESARIĆ I JOSIPA ODOBAŠIĆ', '', 6, '2025-08-05T13:03:05.330+00:00', '2025-08-05T13:03:05.330+00:00', NULL, NULL);
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (292, 'IVANA ODOBAŠIĆ', '', 6, '2025-08-05T13:03:16.911+00:00', '2025-08-05T13:03:16.911+00:00', NULL, NULL);
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (293, 'IVAN BUDIMIR', '', 4, '2025-08-05T13:03:26.284+00:00', '2025-08-05T13:03:26.284+00:00', NULL, NULL);
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (294, 'ANTONETA MICHIELI TOMIĆ', '', 7, '2025-08-05T13:04:03.003+00:00', '2025-08-05T13:04:03.003+00:00', NULL, NULL);
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (295, 'TANJA KAĆUNOKO', '', NULL, '2025-08-05T13:04:22.396+00:00', '2025-08-05T13:04:22.396+00:00', NULL, '+385989031389');
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (296, 'LJUBICA NUJIĆ', '', 8, '2025-08-05T13:04:39.864+00:00', '2025-08-05T13:04:39.864+00:00', NULL, NULL);
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (297, 'NEVENKA IVIĆ', '', 8, '2025-08-05T13:04:54.469+00:00', '2025-08-05T13:04:54.469+00:00', NULL, NULL);
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (298, 'BLAŽENKA ĐUZEL', '', NULL, '2025-08-05T13:05:16.577+00:00', '2025-08-05T13:05:16.577+00:00', NULL, '+491744880568');
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (299, 'LUKA TUNIĆ', '', NULL, '2025-08-05T13:06:22.331+00:00', '2025-08-05T13:06:22.331+00:00', NULL, '+385981969593');
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (300, 'MARIO ČAVAROVIĆ', '', NULL, '2025-08-05T13:06:45.425+00:00', '2025-08-05T13:06:45.425+00:00', 'mariocavarovic@gmail.com', NULL);
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (301, 'IVA BULIĆ', '', NULL, '2025-08-05T13:07:27.945+00:00', '2025-08-05T13:07:27.945+00:00', NULL, '+385997505950');
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (302, 'NIKOLINA BREZETIĆ', '', NULL, '2025-08-05T13:07:46.638+00:00', '2025-08-05T13:07:46.638+00:00', NULL, '+385981656472');
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (303, 'VANJA I TONI GULAM', '', NULL, '2025-08-05T13:08:07.416+00:00', '2025-08-05T13:08:07.416+00:00', NULL, '+385955830915');
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (304, 'NADA I GORAN BAČIĆ', '', 8, '2025-08-05T13:08:25.906+00:00', '2025-08-05T13:08:25.906+00:00', NULL, NULL);
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (305, 'MARA STANUŠIĆ', '', 8, '2025-08-05T13:08:39.984+00:00', '2025-08-05T13:08:39.984+00:00', NULL, NULL);
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (306, 'MIRA MIŠKOVIĆ', '', 8, '2025-08-05T13:09:22.869+00:00', '2025-08-05T13:09:22.869+00:00', NULL, NULL);
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (307, 'SARA NIKOLOZO', '', NULL, '2025-08-05T13:10:22.109+00:00', '2025-08-05T13:10:22.109+00:00', NULL, '+385977372365');
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (308, 'JANJA BUŠIĆ', '', NULL, '2025-08-05T13:10:43.391+00:00', '2025-08-05T13:10:43.391+00:00', NULL, '+385989191677');
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (309, 'SLAVICA PANĐA', '', NULL, '2025-08-05T13:11:08.522+00:00', '2025-08-05T13:11:08.522+00:00', NULL, '+385981852549');
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (310, 'IRENA PETRINEC', '', 4, '2025-08-05T13:11:21.469+00:00', '2025-08-05T13:11:21.469+00:00', NULL, NULL);
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (311, 'ANA JUKIĆ MARKANOVIĆ', 'https://www.facebook.com/ana.jukicmarkanovic', NULL, '2025-08-05T13:12:21.719+00:00', '2025-08-05T13:12:21.719+00:00', NULL, NULL);
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (312, 'MANUEL MAGDIĆ', '', 4, '2025-08-05T13:13:02.306+00:00', '2025-08-05T13:13:02.306+00:00', NULL, NULL);
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (313, 'ILIJA JURKIĆ', '', 8, '2025-08-05T13:13:16.483+00:00', '2025-08-05T13:13:16.483+00:00', NULL, NULL);
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (314, 'SANJA FEHTIG', '', NULL, '2025-08-05T13:13:35.070+00:00', '2025-08-05T13:13:35.070+00:00', 'fehtig.sanja@gmail.com', NULL);
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (315, 'ZLATKO ABRAMAC', '', 5, '2025-08-05T13:17:06.535+00:00', '2025-08-05T13:17:06.535+00:00', NULL, '+385958527615');
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (316, 'ANTOLA PETRIĆ (LJUBNA)', '', NULL, '2025-08-05T13:17:33.852+00:00', '2025-08-05T13:17:33.852+00:00', NULL, '+38763029922');
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (317, 'DEJANA', '', NULL, '2025-08-05T13:17:52.147+00:00', '2025-08-05T13:17:52.147+00:00', NULL, '+385955368260');
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (318, 'GORDANA MIJAKIĆ', '', 4, '2025-08-05T13:18:03.342+00:00', '2025-08-05T13:18:03.342+00:00', NULL, NULL);
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (319, 'LEO PROFACA', '', NULL, '2025-08-05T13:18:18.556+00:00', '2025-08-05T13:18:18.556+00:00', NULL, '+38598496806');
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (320, 'RUŽICA KLARIĆ', '', NULL, '2025-08-05T13:18:33.760+00:00', '2025-08-05T13:18:33.760+00:00', NULL, '+385917503574');
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (321, 'DRAŽEN KOVAČEVIĆ', '', 4, '2025-08-05T13:19:15.408+00:00', '2025-08-05T13:19:15.408+00:00', NULL, NULL);
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (322, 'MIRA BRDARIĆ', '', 6, '2025-08-05T13:19:35.737+00:00', '2025-08-05T13:19:35.737+00:00', NULL, NULL);
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (323, 'ANTE GUDELJ', '', 6, '2025-08-05T13:19:46.452+00:00', '2025-08-05T13:19:46.452+00:00', NULL, NULL);
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (324, 'MILJENKO JURILJ', '', 6, '2025-08-05T13:19:58.970+00:00', '2025-08-05T13:19:58.970+00:00', NULL, NULL);
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (325, 'MARICA KAURIN', '', 6, '2025-08-05T13:20:12.686+00:00', '2025-08-05T13:20:12.686+00:00', NULL, NULL);
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (326, 'NEDA KOVČIĆ', '', 6, '2025-08-05T13:21:14.194+00:00', '2025-08-05T13:21:14.194+00:00', NULL, NULL);
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (327, 'OBITELJ IZ ZAGREBA', '', NULL, '2025-08-05T13:21:56.630+00:00', '2025-08-05T13:21:56.630+00:00', NULL, '+385918988779');
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (328, 'BARBARA RAJKOVIĆ', '', NULL, '2025-08-05T13:22:16.219+00:00', '2025-08-05T13:22:16.219+00:00', 'barbara.rajkovic@gmail.com', NULL);
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (329, 'ANITA KOLANOVIĆ', '', NULL, '2025-08-05T13:23:08.540+00:00', '2025-08-05T13:23:08.540+00:00', NULL, '+385993287339');
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (330, 'LJUBICA ILJAZOVIĆ', '', NULL, '2025-08-05T13:23:26.218+00:00', '2025-08-05T13:23:26.218+00:00', NULL, '+385993852716');
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (331, 'MIRELA MILIČEVIĆ', '', NULL, '2025-08-05T13:23:46.908+00:00', '2025-08-05T13:23:46.908+00:00', 'mirelamilicevic1612@gmail.com', NULL);
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (332, 'BOŽENA LEONTIĆ ŽELJKO', '', NULL, '2025-08-05T13:24:04.799+00:00', '2025-08-05T13:24:04.799+00:00', NULL, '+385994439126');
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (333, 'LINDA MILOVAC', '', NULL, '2025-08-05T13:24:33.190+00:00', '2025-08-05T13:24:33.190+00:00', NULL, '+385915914290');
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (334, 'IVANA LIKAREVIĆ', '', 6, '2025-08-05T13:24:48.366+00:00', '2025-08-05T13:24:48.366+00:00', NULL, NULL);
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (335, 'ZORAN MATANOVIĆ', '', 6, '2025-08-05T13:24:58.582+00:00', '2025-08-05T13:24:58.582+00:00', NULL, NULL);
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (336, 'KAJA NIKIĆ', '', 6, '2025-08-05T13:25:08.051+00:00', '2025-08-05T13:25:08.051+00:00', NULL, NULL);
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (337, 'MANDA ARAČIĆ', '', 6, '2025-08-05T13:25:19.921+00:00', '2025-08-05T13:25:19.921+00:00', NULL, NULL);
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (338, 'MIRA JAJČANIN BIJELJINA', '', 9, '2025-08-05T13:25:45.122+00:00', '2025-08-05T13:25:45.122+00:00', NULL, NULL);
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (339, 'MILKA PERIĆ BIJELJINA', '', 9, '2025-08-05T13:25:59.605+00:00', '2025-08-05T13:25:59.605+00:00', NULL, NULL);
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (340, 'OBITELJ TERZIĆ', '', 8, '2025-08-05T13:26:17.685+00:00', '2025-08-05T13:26:17.685+00:00', NULL, NULL);
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (341, 'MARKO JUKIĆ INVALID', '', 14, '2025-08-05T13:27:26.236+00:00', '2025-08-05T13:27:26.236+00:00', NULL, NULL);
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (342, 'PRIEST ŽELJKO MARIĆ', '', NULL, '2025-08-05T13:27:50.400+00:00', '2025-08-05T13:27:50.400+00:00', NULL, '+38763906241');
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (343, 'ANICA VRDOLJAK', '', NULL, '2025-08-05T13:28:26.600+00:00', '2025-08-05T13:28:26.600+00:00', 'anicavrd@gmail.com', NULL);
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (344, 'MARIJA KLARIĆ', '', NULL, '2025-08-05T13:28:48.550+00:00', '2025-08-05T13:28:48.550+00:00', 'milkovicka88@gmail.com', NULL);
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (345, 'SLAĐAN TUNIĆ', '', 10, '2025-08-05T13:29:46.198+00:00', '2025-08-05T13:29:46.198+00:00', NULL, NULL);
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (346, 'KRISTINA', '', NULL, '2025-08-05T13:30:02.012+00:00', '2025-08-05T13:30:02.012+00:00', NULL, '+385913002057');
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (347, 'BOŽICA FRANCIĆ', '', NULL, '2025-08-05T13:30:37.047+00:00', '2025-08-05T13:30:37.047+00:00', NULL, '+385996848461');
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (348, 'LEONARDA ANĐELA TOMIĆ', '', NULL, '2025-08-05T13:30:55.777+00:00', '2025-08-05T13:30:55.777+00:00', NULL, '+385955076805');
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (349, 'KARMEN JUGINOVIĆ', '', NULL, '2025-08-05T13:31:21.357+00:00', '2025-08-05T13:31:21.357+00:00', 'juginovickarmen@gmail.com', NULL);
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (350, 'SLAVICA ILIĆ', '', NULL, '2025-08-05T13:31:45.688+00:00', '2025-08-05T13:31:45.688+00:00', 'islavica2@gmail.com', NULL);
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (351, 'SNJEŽANA VINTERFELD', '', 9, '2025-08-05T13:32:08.975+00:00', '2025-08-05T13:32:08.975+00:00', NULL, NULL);
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (352, 'POKOJNOG VABECA RODITELJI TROJE DJECE', '', 5, '2025-08-05T13:33:13.793+00:00', '2025-08-05T13:33:13.793+00:00', NULL, NULL);
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (353, 'ANA MARIJA ZA ŽUPE WHATSAPP', '', NULL, '2025-08-05T13:33:57.786+00:00', '2025-08-05T13:33:57.786+00:00', NULL, NULL);
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (354, 'VJEKOSLAV HANŽEK', '', 4, '2025-08-05T13:34:28.906+00:00', '2025-08-05T13:34:28.906+00:00', NULL, NULL);
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (355, 'VLATKO SOLDO', '', 4, '2025-08-05T13:34:39.629+00:00', '2025-08-05T13:34:39.629+00:00', NULL, NULL);
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (356, 'PAVAO I NEVENKA JURIĆ', '', NULL, '2025-08-05T13:34:56.056+00:00', '2025-08-05T13:34:56.056+00:00', NULL, '+38763764506');
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (357, 'STJEPAN VUKOVIĆ', '', 6, '2025-08-05T13:35:13.135+00:00', '2025-08-05T13:35:13.135+00:00', NULL, NULL);
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (358, 'KRISTINA LEBIĆ', '', 6, '2025-08-05T13:35:26.003+00:00', '2025-08-05T13:35:26.003+00:00', NULL, NULL);
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (359, 'MIRNA RAŽEK', '', 6, '2025-08-05T13:35:41.736+00:00', '2025-08-05T13:35:41.736+00:00', NULL, NULL);
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (360, 'MARTA KOVAČ', '', NULL, '2025-08-05T13:35:57.598+00:00', '2025-08-05T13:35:57.598+00:00', NULL, '+38598598450');
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (361, 'UDRUGA ŽIVOT', '', 8, '2025-08-05T13:36:32.254+00:00', '2025-08-05T13:36:32.254+00:00', NULL, NULL);
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (362, 'IVANKA KOBAŠ', '', NULL, '2025-08-05T13:36:52.074+00:00', '2025-08-05T13:36:52.074+00:00', 'ivankakobas@gmail.com', NULL);
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (363, 'ANITA I BOŽO FILIĆ', '', 7, '2025-08-05T13:37:24.465+00:00', '2025-08-05T13:37:24.465+00:00', NULL, NULL);
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (364, 'LEONARDA DEZE', '', 4, '2025-08-05T13:37:46.711+00:00', '2025-08-05T13:37:46.711+00:00', NULL, NULL);
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (365, 'IVAN LEVAK', '', 7, '2025-08-05T13:37:58.890+00:00', '2025-08-05T13:37:58.890+00:00', NULL, NULL);
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (366, 'FRANJO FRANCIĆ', '', 7, '2025-08-05T13:38:13.412+00:00', '2025-08-05T13:38:13.412+00:00', NULL, NULL);
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (367, 'SAŠA TOMASIĆ KAŽEK', '', 7, '2025-08-05T13:38:33.462+00:00', '2025-08-05T13:38:33.462+00:00', NULL, NULL);
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (368, 'PATRICIJA I ANTE DUVNJAK', '', 7, '2025-08-05T13:38:53.618+00:00', '2025-08-05T13:38:53.618+00:00', NULL, NULL);
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (369, 'MARJAN ANDREIĆ', '', 7, '2025-08-05T13:39:10.961+00:00', '2025-08-05T13:39:10.961+00:00', NULL, NULL);
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (370, 'FRANJO LAZARIN', '', NULL, '2025-08-05T13:39:30.788+00:00', '2025-08-05T13:39:30.788+00:00', NULL, '+385917906137');
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (371, 'NINA MARINKO', '', NULL, '2025-08-05T13:39:47.976+00:00', '2025-08-05T13:39:47.976+00:00', NULL, '+385993275353');
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (372, 'BRANIMIR KOLARIĆ', '', NULL, '2025-08-05T13:40:35.180+00:00', '2025-08-05T13:40:35.180+00:00', NULL, '+385955093672');
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (373, 'JANJA MARIJANOVIĆ', '', NULL, '2025-08-05T13:41:01.500+00:00', '2025-08-05T13:41:01.500+00:00', 'janja.marijanovic@skole.hr', NULL);
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (374, 'SNJEŽANA JURANIĆ', '', NULL, '2025-08-05T13:41:23.269+00:00', '2025-08-05T13:41:23.269+00:00', 'snjezana.juranic@gmail.ocm', NULL);
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (375, 'KRUNOSLAV LUKŠIĆ', '', NULL, '2025-08-05T13:42:03.091+00:00', '2025-08-05T13:42:03.091+00:00', NULL, '+385919808843');
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (376, 'IRENA PARIPOVIĆ', '', NULL, '2025-08-05T13:42:24.538+00:00', '2025-08-05T13:42:24.538+00:00', 'irenaparipovic@gmail.com', NULL);
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (377, 'TONI DURČINOVIĆ', '', NULL, '2025-08-05T13:42:39.430+00:00', '2025-08-05T13:42:39.430+00:00', NULL, '+385953996524');
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (378, 'DALIBOR BAKULA', '', NULL, '2025-08-05T13:42:58.288+00:00', '2025-08-05T13:42:58.288+00:00', NULL, '+38763358337');
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (379, 'MIRNA ALVIR', '', 7, '2025-08-05T13:43:12.387+00:00', '2025-08-05T13:43:12.387+00:00', NULL, NULL);
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (380, 'MARINKA BIKIĆ', '', NULL, '2025-08-05T13:43:29.181+00:00', '2025-08-05T13:43:29.181+00:00', NULL, '+38766002537');
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (381, 'SLAVICA I ANTUN RADIČEVIĆ', '', 6, '2025-08-05T13:44:12.627+00:00', '2025-08-05T13:44:12.627+00:00', NULL, NULL);
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (382, 'MARTIN KRIZMANIĆ', '', NULL, '2025-08-05T13:44:28.151+00:00', '2025-08-05T13:44:28.151+00:00', NULL, '+385918948964');
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (383, 'KATICA JURČEVIĆ', '', NULL, '2025-08-05T13:44:48.685+00:00', '2025-08-05T13:44:48.685+00:00', NULL, '+38598623230');
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (384, 'MARIJANA MODRIĆ', '', NULL, '2025-08-05T13:45:05.658+00:00', '2025-08-05T13:45:05.658+00:00', NULL, '+385915612662');
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (385, 'DANI SESAR', '', 4, '2025-08-05T13:45:14.320+00:00', '2025-08-05T13:45:14.320+00:00', NULL, NULL);
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (386, 'MARIO BLEK (LJUBNA)', '', NULL, '2025-08-05T13:46:03.963+00:00', '2025-08-05T13:46:03.963+00:00', NULL, '+38763144481');
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (387, 'VERONIKA AVGUSTINOVIĆ', '', 6, '2025-08-05T13:46:21.993+00:00', '2025-08-05T13:46:21.993+00:00', NULL, NULL);
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (388, 'GORDANA', '', NULL, '2025-08-05T13:46:52.302+00:00', '2025-08-05T13:46:52.302+00:00', NULL, '+385914220811');
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (389, 'BERO JUKIĆ (JANJA)', '', NULL, '2025-08-05T13:47:32.879+00:00', '2025-08-05T13:47:32.879+00:00', NULL, '+38763376035');
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (390, 'MARGARETA RIBIČIĆ', '', NULL, '2025-08-05T13:48:30.539+00:00', '2025-08-05T13:48:30.539+00:00', NULL, '+385981852549');
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (391, 'SNJEŽANA I IVICA UDOVČIĆ', '', NULL, '2025-08-05T13:48:51.220+00:00', '2025-08-05T13:48:51.220+00:00', NULL, '+38763722511');
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (392, 'TADO ANDRIĆ (ŽEPČE)', '', NULL, '2025-08-05T13:49:15.109+00:00', '2025-08-05T13:49:15.109+00:00', NULL, '+38763236611');
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (393, 'ANA I MATEA', '', 6, '2025-08-05T13:49:27.349+00:00', '2025-08-05T13:49:27.349+00:00', NULL, NULL);
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (394, 'LJUBA PAVLAŠIĆ I SLAVKA LOVRIĆ', '', NULL, '2025-08-05T13:49:52.999+00:00', '2025-08-05T13:49:52.999+00:00', NULL, '+385981852549');
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (395, 'MIRKO TOMIĆ', 'FB', NULL, '2025-08-05T13:50:09.217+00:00', '2025-08-05T13:50:09.217+00:00', NULL, NULL);
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (396, 'MARTIN BANDIĆ', '', NULL, '2025-08-05T13:50:31.028+00:00', '2025-08-05T13:50:31.028+00:00', 'kaja.paric@gmail.com', NULL);
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (397, 'SPOMENKA I LUKA LUKANOVIĆ', '', 9, '2025-08-05T13:50:49.622+00:00', '2025-08-05T13:50:49.622+00:00', NULL, NULL);
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (398, 'IVA BABIĆ', '', NULL, '2025-08-05T13:51:13.978+00:00', '2025-08-05T13:51:13.978+00:00', 'iva11babic@gmail.com', NULL);
INSERT INTO sponsors (id, fullName, contact, proxyId, createdAt, updatedAt, email, phone) VALUES (399, 'ARANKA BENCE', '', 4, '2025-08-05T13:51:33.725+00:00', '2025-08-05T13:51:33.725+00:00', NULL, NULL);

CREATE TABLE "proxies" (
    "id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
    "fullName" TEXT NOT NULL,
    "contact" TEXT NOT NULL,
    "role" TEXT,
    "description" TEXT,
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" DATETIME NOT NULL
, email TEXT, phone TEXT);

INSERT INTO proxies (id, fullName, contact, role, description, createdAt, updatedAt, email, phone) VALUES (4, 'PRIEST JOSIP ERJAVAC', '+385989768295', 'Priest', NULL, '2025-08-05T06:46:09.350+00:00', '2025-08-05T06:46:09.350+00:00', NULL, NULL);
INSERT INTO proxies (id, fullName, contact, role, description, createdAt, updatedAt, email, phone) VALUES (5, 'JURAJ JUKIĆ', '', '-', NULL, '2025-08-05T07:14:27.581+00:00', '2025-08-05T07:14:27.581+00:00', NULL, '+38763851296');
INSERT INTO proxies (id, fullName, contact, role, description, createdAt, updatedAt, email, phone) VALUES (6, 'LUKA ĆOSIĆ', '', 'PRIEST', NULL, '2025-08-05T07:15:25.749+00:00', '2025-08-05T07:15:25.749+00:00', 'lux.cosic@gmail.com', NULL);
INSERT INTO proxies (id, fullName, contact, role, description, createdAt, updatedAt, email, phone) VALUES (7, 'BOŽICA FRANČIĆ', '', 'VOLONTERKA', NULL, '2025-08-05T07:19:19.850+00:00', '2025-08-05T07:19:19.850+00:00', NULL, '+385996848461');
INSERT INTO proxies (id, fullName, contact, role, description, createdAt, updatedAt, email, phone) VALUES (8, 'PRIEST ILIJA ORKIĆ', '', 'PRIEST', NULL, '2025-08-05T07:23:43.812+00:00', '2025-08-05T07:23:43.812+00:00', NULL, '+38763342342');
INSERT INTO proxies (id, fullName, contact, role, description, createdAt, updatedAt, email, phone) VALUES (9, 'PRIEST LUKANOVIĆ', '', 'PRIEST', NULL, '2025-08-05T07:38:32.875+00:00', '2025-08-05T07:38:32.875+00:00', NULL, '+38763382026');
INSERT INTO proxies (id, fullName, contact, role, description, createdAt, updatedAt, email, phone) VALUES (10, 'LUKA TUNIĆ', '', '-', NULL, '2025-08-05T07:40:08.489+00:00', '2025-08-05T07:40:08.489+00:00', NULL, '+385981969593');
INSERT INTO proxies (id, fullName, contact, role, description, createdAt, updatedAt, email, phone) VALUES (11, 'ANA CVITKUŠIĆ', '', '-', NULL, '2025-08-05T07:44:56.981+00:00', '2025-08-05T07:44:56.981+00:00', NULL, '+4369917082325');
INSERT INTO proxies (id, fullName, contact, role, description, createdAt, updatedAt, email, phone) VALUES (12, 'BRANKO IVAN PERVAN', 'https://www.facebook.com/brankoivan.pervan.3', '-', NULL, '2025-08-05T08:04:20.304+00:00', '2025-08-05T08:04:20.304+00:00', NULL, NULL);
INSERT INTO proxies (id, fullName, contact, role, description, createdAt, updatedAt, email, phone) VALUES (13, 'KATARINA SKENDEROVIĆ', '', 'DAUGHTER', NULL, '2025-08-05T08:05:53.385+00:00', '2025-08-05T08:05:53.385+00:00', NULL, '+385989947284');
INSERT INTO proxies (id, fullName, contact, role, description, createdAt, updatedAt, email, phone) VALUES (14, 'ANA JUKIĆ MARKANOVIĆ', 'FB https://www.facebook.com/ana.jukicmarkanovic', '-', NULL, '2025-08-05T13:27:25.812+00:00', '2025-08-05T13:27:25.812+00:00', NULL, NULL);

CREATE TABLE "sponsorships" (
    "id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
    "childId" INTEGER NOT NULL,
    "sponsorId" INTEGER NOT NULL,
    "startDate" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "endDate" DATETIME,
    "monthlyAmount" REAL,
    "paymentMethod" TEXT,
    "isActive" BOOLEAN NOT NULL DEFAULT true,
    "notes" TEXT,
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" DATETIME NOT NULL,
    CONSTRAINT "sponsorships_childId_fkey" FOREIGN KEY ("childId") REFERENCES "children" ("id") ON DELETE RESTRICT ON UPDATE CASCADE,
    CONSTRAINT "sponsorships_sponsorId_fkey" FOREIGN KEY ("sponsorId") REFERENCES "sponsors" ("id") ON DELETE RESTRICT ON UPDATE CASCADE
);

INSERT INTO sponsorships (id, childId, sponsorId, startDate, endDate, monthlyAmount, paymentMethod, isActive, notes, createdAt, updatedAt) VALUES (60, 41, 47, '2025-08-05T06:27:23.302+00:00', NULL, NULL, NULL, 1, NULL, '2025-08-05T06:27:23.303+00:00', '2025-08-05T06:27:23.303+00:00');
INSERT INTO sponsorships (id, childId, sponsorId, startDate, endDate, monthlyAmount, paymentMethod, isActive, notes, createdAt, updatedAt) VALUES (61, 42, 48, '2025-08-05T06:31:08.400+00:00', NULL, NULL, NULL, 1, NULL, '2025-08-05T06:31:08.401+00:00', '2025-08-05T06:31:08.401+00:00');
INSERT INTO sponsorships (id, childId, sponsorId, startDate, endDate, monthlyAmount, paymentMethod, isActive, notes, createdAt, updatedAt) VALUES (62, 43, 49, '2025-08-05T06:35:10.612+00:00', NULL, NULL, NULL, 1, NULL, '2025-08-05T06:35:10.613+00:00', '2025-08-05T06:35:10.613+00:00');
INSERT INTO sponsorships (id, childId, sponsorId, startDate, endDate, monthlyAmount, paymentMethod, isActive, notes, createdAt, updatedAt) VALUES (63, 44, 50, '2025-08-05T06:37:58.777+00:00', NULL, NULL, NULL, 1, NULL, '2025-08-05T06:37:58.778+00:00', '2025-08-05T06:37:58.778+00:00');
INSERT INTO sponsorships (id, childId, sponsorId, startDate, endDate, monthlyAmount, paymentMethod, isActive, notes, createdAt, updatedAt) VALUES (64, 45, 51, '2025-08-05T06:40:38.634+00:00', NULL, NULL, NULL, 1, NULL, '2025-08-05T06:40:38.635+00:00', '2025-08-05T06:40:38.635+00:00');
INSERT INTO sponsorships (id, childId, sponsorId, startDate, endDate, monthlyAmount, paymentMethod, isActive, notes, createdAt, updatedAt) VALUES (65, 45, 50, '2025-08-05T06:41:08.202+00:00', NULL, NULL, NULL, 1, NULL, '2025-08-05T06:41:08.203+00:00', '2025-08-05T06:41:08.203+00:00');
INSERT INTO sponsorships (id, childId, sponsorId, startDate, endDate, monthlyAmount, paymentMethod, isActive, notes, createdAt, updatedAt) VALUES (66, 43, 52, '2025-08-05T06:46:45.209+00:00', NULL, NULL, NULL, 1, NULL, '2025-08-05T06:46:45.211+00:00', '2025-08-05T06:46:45.211+00:00');
INSERT INTO sponsorships (id, childId, sponsorId, startDate, endDate, monthlyAmount, paymentMethod, isActive, notes, createdAt, updatedAt) VALUES (67, 43, 53, '2025-08-05T06:46:51.193+00:00', NULL, NULL, NULL, 1, NULL, '2025-08-05T06:46:51.194+00:00', '2025-08-05T06:46:51.194+00:00');
INSERT INTO sponsorships (id, childId, sponsorId, startDate, endDate, monthlyAmount, paymentMethod, isActive, notes, createdAt, updatedAt) VALUES (68, 44, 54, '2025-08-05T06:49:31.553+00:00', NULL, NULL, NULL, 1, NULL, '2025-08-05T06:49:31.555+00:00', '2025-08-05T06:49:31.555+00:00');
INSERT INTO sponsorships (id, childId, sponsorId, startDate, endDate, monthlyAmount, paymentMethod, isActive, notes, createdAt, updatedAt) VALUES (69, 46, 55, '2025-08-05T06:52:47.982+00:00', NULL, NULL, NULL, 1, NULL, '2025-08-05T06:52:47.983+00:00', '2025-08-05T06:52:47.983+00:00');
INSERT INTO sponsorships (id, childId, sponsorId, startDate, endDate, monthlyAmount, paymentMethod, isActive, notes, createdAt, updatedAt) VALUES (70, 46, 52, '2025-08-05T06:53:40.736+00:00', NULL, NULL, NULL, 1, NULL, '2025-08-05T06:53:40.737+00:00', '2025-08-05T06:53:40.737+00:00');
INSERT INTO sponsorships (id, childId, sponsorId, startDate, endDate, monthlyAmount, paymentMethod, isActive, notes, createdAt, updatedAt) VALUES (71, 47, 56, '2025-08-05T06:56:22.736+00:00', NULL, NULL, NULL, 1, NULL, '2025-08-05T06:56:22.737+00:00', '2025-08-05T06:56:22.737+00:00');
INSERT INTO sponsorships (id, childId, sponsorId, startDate, endDate, monthlyAmount, paymentMethod, isActive, notes, createdAt, updatedAt) VALUES (72, 47, 50, '2025-08-05T06:56:47.039+00:00', NULL, NULL, NULL, 1, NULL, '2025-08-05T06:56:47.040+00:00', '2025-08-05T06:56:47.040+00:00');
INSERT INTO sponsorships (id, childId, sponsorId, startDate, endDate, monthlyAmount, paymentMethod, isActive, notes, createdAt, updatedAt) VALUES (73, 48, 57, '2025-08-05T07:01:12.700+00:00', NULL, NULL, NULL, 1, NULL, '2025-08-05T07:01:12.701+00:00', '2025-08-05T07:01:12.701+00:00');
INSERT INTO sponsorships (id, childId, sponsorId, startDate, endDate, monthlyAmount, paymentMethod, isActive, notes, createdAt, updatedAt) VALUES (74, 48, 52, '2025-08-05T07:01:31.956+00:00', NULL, NULL, NULL, 1, NULL, '2025-08-05T07:01:31.957+00:00', '2025-08-05T07:01:31.957+00:00');

CREATE TABLE "volunteers" (
    "id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
    "firstName" TEXT NOT NULL,
    "lastName" TEXT NOT NULL,
    "email" TEXT NOT NULL,
    "phone" TEXT,
    "role" TEXT NOT NULL DEFAULT 'volunteer',
    "isActive" BOOLEAN NOT NULL DEFAULT true,
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" DATETIME NOT NULL
);

COMMIT;
