PRAGMA foreign_keys=OFF;
BEGIN TRANSACTION;

CREATE TABLE "children" (
    "id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
    "firstName" TEXT NOT NULL,
    "lastName" TEXT NOT NULL,
    "dateOfBirth" DATETIME NOT NULL,
    "gender" TEXT NOT NULL,
    "schoolId" INTEGER NOT NULL,
    "class" TEXT NOT NULL,
    "fatherFullName" TEXT NOT NULL,
    "fatherAddress" TEXT,
    "fatherContact" TEXT,
    "motherFullName" TEXT NOT NULL,
    "motherAddress" TEXT,
    "motherContact" TEXT,
    "story" TEXT,
    "comment" TEXT,
    "dateEnteredRegister" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "lastProfileUpdate" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "isSponsored" BOOLEAN NOT NULL DEFAULT false,
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" DATETIME NOT NULL,
    CONSTRAINT "children_schoolId_fkey" FOREIGN KEY ("schoolId") REFERENCES "schools" ("id") ON DELETE RESTRICT ON UPDATE CASCADE
);

CREATE TABLE "child_photos" (
    "id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
    "childId" INTEGER NOT NULL,
    "photoBase64" TEXT NOT NULL,
    "mimeType" TEXT NOT NULL,
    "fileName" TEXT,
    "fileSize" INTEGER,
    "description" TEXT,
    "uploadedAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "isProfile" BOOLEAN NOT NULL DEFAULT false,
    CONSTRAINT "child_photos_childId_fkey" FOREIGN KEY ("childId") REFERENCES "children" ("id") ON DELETE CASCADE ON UPDATE CASCADE
);

CREATE TABLE "schools" (
    "id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
    "name" TEXT NOT NULL,
    "location" TEXT,
    "isActive" BOOLEAN NOT NULL DEFAULT true
);

INSERT INTO schools (id, name, location, isActive) VALUES (2, 'ABIM SECONDARY SCHOOL', 'Abim', 1);
INSERT INTO schools (id, name, location, isActive) VALUES (3, 'ABIM TECHNICAL INSTITUTE', 'Abim', 1);
INSERT INTO schools (id, name, location, isActive) VALUES (4, 'ACHUKUDU COMMUNITY PRIMARY SCHOOL', 'Achukudu', 1);
INSERT INTO schools (id, name, location, isActive) VALUES (5, 'ADEA PRIMARY SCHOOL', 'Adea', 1);
INSERT INTO schools (id, name, location, isActive) VALUES (6, 'ADWARI SECONDARY SCHOOL', 'Adwari', 1);
INSERT INTO schools (id, name, location, isActive) VALUES (7, 'AKIGENO NURSERY AND PRIMARY SCHOOL', 'Akigeno', 1);
INSERT INTO schools (id, name, location, isActive) VALUES (8, 'AKWANGAGWEL PRIMARY SCHOOL', 'Akwangagwel', 1);
INSERT INTO schools (id, name, location, isActive) VALUES (9, 'ALIR PRIMARY SCHOOL', 'Alir', 1);
INSERT INTO schools (id, name, location, isActive) VALUES (10, 'ANKOLE INSTITUTE OF BUSINESS AND VOCATIONAL STUDIES', 'Mbarara', 1);
INSERT INTO schools (id, name, location, isActive) VALUES (11, 'APOSTLES OF JESUS SEMINARY', 'Moroto', 1);
INSERT INTO schools (id, name, location, isActive) VALUES (12, 'ARAPAI AGRICULTURAL COLLEGE', 'Soroti', 1);
INSERT INTO schools (id, name, location, isActive) VALUES (13, 'BUSITEMA UNIVERSITY SOROTI BRANCH', 'Soroti', 1);
INSERT INTO schools (id, name, location, isActive) VALUES (14, 'FATHER BASH FOUNDATION', 'Uganda', 1);
INSERT INTO schools (id, name, location, isActive) VALUES (15, 'FLORENCE NIGHTINGALE SCHOOL OF NURSING AND MIDWIFERY', 'Uganda', 1);
INSERT INTO schools (id, name, location, isActive) VALUES (16, 'GLORY NURSERY AND PRIMARY SCHOOL', 'Uganda', 1);
INSERT INTO schools (id, name, location, isActive) VALUES (17, 'GOOD DADDY NURSERY AND PRIMARY SCHOOL', 'Uganda', 1);
INSERT INTO schools (id, name, location, isActive) VALUES (18, 'GULU UNIVERSITY', 'Gulu', 1);
INSERT INTO schools (id, name, location, isActive) VALUES (19, 'HALCYON HIGH SCHOOL', 'Uganda', 1);
INSERT INTO schools (id, name, location, isActive) VALUES (20, 'HUMAN DEVELOPMENT TECHNICAL TRAINING SCHOOL', 'Lira', 1);
INSERT INTO schools (id, name, location, isActive) VALUES (21, 'IMMACULATE HEART OF MARY', 'Uganda', 1);
INSERT INTO schools (id, name, location, isActive) VALUES (22, 'INTERNATIONAL INSTITUTE OF HEALTH SCIENCES', 'Jinja', 1);
INSERT INTO schools (id, name, location, isActive) VALUES (23, 'JUBILEE 2000 SSS', 'Karenga', 1);
INSERT INTO schools (id, name, location, isActive) VALUES (24, 'KAMPALA INTERNATIONAL UNIVERSITY', 'Kampala', 1);
INSERT INTO schools (id, name, location, isActive) VALUES (25, 'KANGOLE GIRLS PRIMARY SCHOOL', 'Kangole', 1);
INSERT INTO schools (id, name, location, isActive) VALUES (26, 'KANGOLE GIRLS SECONDARY SCHOOL', 'Kangole', 1);
INSERT INTO schools (id, name, location, isActive) VALUES (27, 'KING''S KID PRIMARY SCHOOL', 'Uganda', 1);
INSERT INTO schools (id, name, location, isActive) VALUES (28, 'KOMUKUNY BOYS PRIMARY SCHOOL', 'Komukuny', 1);
INSERT INTO schools (id, name, location, isActive) VALUES (29, 'LIRA CENTRAL PRIMARY SCHOOL', 'Lira', 1);
INSERT INTO schools (id, name, location, isActive) VALUES (30, 'LOTUKE SEED SECONDARY SCHOOL', 'Lotuke', 1);
INSERT INTO schools (id, name, location, isActive) VALUES (31, 'LUZIRA SECONDARY SCHOOL', 'Luzira', 1);
INSERT INTO schools (id, name, location, isActive) VALUES (32, 'MAKERERE UNIVERSITY', 'Kampala', 1);
INSERT INTO schools (id, name, location, isActive) VALUES (33, 'MAKERERE UNIVERSITY JINJA CAMPUS', 'Jinja', 1);
INSERT INTO schools (id, name, location, isActive) VALUES (34, 'MBALE SCHOOL FOR THE DEAF', 'Mbale', 1);
INSERT INTO schools (id, name, location, isActive) VALUES (35, 'MBALE SCHOOL FOR THE DEAF - HAIRDRESSING', 'Mbale', 1);
INSERT INTO schools (id, name, location, isActive) VALUES (36, 'MBARARA UNIVERSITY SCIENCE AND TECHNOLOGY', 'Mbarara', 1);
INSERT INTO schools (id, name, location, isActive) VALUES (37, 'MITYANA STANDARD SECONDARY SCHOOL', 'Gagavu', 1);
INSERT INTO schools (id, name, location, isActive) VALUES (38, 'MORULEM BOYS PRIMARY SCHOOL', 'Morulem', 1);
INSERT INTO schools (id, name, location, isActive) VALUES (39, 'MORULEM GIRLS PRIMARY SCHOOL', 'Morulem', 1);
INSERT INTO schools (id, name, location, isActive) VALUES (40, 'MORULEM GIRLS SECONDARY SCHOOL', 'Morulem', 1);
INSERT INTO schools (id, name, location, isActive) VALUES (41, 'NALAKAS PRIMARY SCHOOL', 'Nalakas', 1);
INSERT INTO schools (id, name, location, isActive) VALUES (42, 'NILE VOCATIONAL INSTITUTE', 'Jinja', 1);
INSERT INTO schools (id, name, location, isActive) VALUES (43, 'NSAMIZI TRAINING INSTITUTE OF SOCIAL DEVELOPMENT', 'Uganda', 1);
INSERT INTO schools (id, name, location, isActive) VALUES (44, 'NYAKWAE SEED SECONDARY SCHOOL', 'Nyakwae', 1);
INSERT INTO schools (id, name, location, isActive) VALUES (45, 'OBOLOKOME PRIMARY SCHOOL', 'Obolokome', 1);
INSERT INTO schools (id, name, location, isActive) VALUES (46, 'OJWINA PRIMARY SCHOOL', 'Ojwina', 1);
INSERT INTO schools (id, name, location, isActive) VALUES (47, 'ORETA PRIMARY SCHOOL', 'Oreta', 1);
INSERT INTO schools (id, name, location, isActive) VALUES (48, 'POPE JOHN PAUL II MEMORIAL SECONDARY SCHOOL', 'Uganda', 1);
INSERT INTO schools (id, name, location, isActive) VALUES (49, 'RACHKOKO PRIMARY SCHOOL', 'Rachkoko', 1);
INSERT INTO schools (id, name, location, isActive) VALUES (50, 'SISTO MAZZOLDI NURSERY AND PRIMARY SCHOOL', 'Uganda', 1);
INSERT INTO schools (id, name, location, isActive) VALUES (51, 'SOROTI TRAINING INSTITUTE', 'Soroti', 1);
INSERT INTO schools (id, name, location, isActive) VALUES (52, 'SOROTI UNIVERSITY', 'Soroti', 1);
INSERT INTO schools (id, name, location, isActive) VALUES (53, 'ST ANDREW''S SECONDARY SCHOOL', 'Obalanga', 1);
INSERT INTO schools (id, name, location, isActive) VALUES (54, 'ST. DANIEL COMBONI PRIMARY SCHOOL', 'Uganda', 1);
INSERT INTO schools (id, name, location, isActive) VALUES (55, 'ST. KATHERINE SENIOR SECONDARY SCHOOL', 'Lira', 1);
INSERT INTO schools (id, name, location, isActive) VALUES (56, 'ST. KIZITO NURSERY AND PRIMARY SCHOOL', 'Amul', 1);
INSERT INTO schools (id, name, location, isActive) VALUES (57, 'ST. KIZITO PRIMARY SCHOOL', 'Amul', 1);
INSERT INTO schools (id, name, location, isActive) VALUES (58, 'ST. MARY''S COLLEGE ABOKE', 'Aboke', 1);
INSERT INTO schools (id, name, location, isActive) VALUES (59, 'ST. MARY''S NURSERY AND PRIMARY SCHOOL', 'Uganda', 1);
INSERT INTO schools (id, name, location, isActive) VALUES (60, 'ST. MARY''S SEMINARY', 'Nadiket', 1);
INSERT INTO schools (id, name, location, isActive) VALUES (61, 'ST. PETER AND PAUL PRIMARY SCHOOL', 'Achukudu', 1);
INSERT INTO schools (id, name, location, isActive) VALUES (62, 'ST. PHILOMENA JUNIOR', 'Uganda', 1);
INSERT INTO schools (id, name, location, isActive) VALUES (63, 'ST. THERESA NURSERY', 'Uganda', 1);
INSERT INTO schools (id, name, location, isActive) VALUES (64, 'STARLIGHT NURSERY SCHOOL', 'Uganda', 1);
INSERT INTO schools (id, name, location, isActive) VALUES (65, 'TOTO MARIA VOCATIONAL TRAINING CENTER', 'Uganda', 1);
INSERT INTO schools (id, name, location, isActive) VALUES (66, 'YMCA WANDEGEYA', 'Wandegeya', 1);
INSERT INTO schools (id, name, location, isActive) VALUES (67, 'ST. GRACIOUS S S LIRA', 'Lira', 1);

CREATE TABLE "sponsors" (
    "id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
    "fullName" TEXT NOT NULL,
    "contact" TEXT NOT NULL,
    "proxyId" INTEGER,
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" DATETIME NOT NULL, email TEXT, phone TEXT,
    CONSTRAINT "sponsors_proxyId_fkey" FOREIGN KEY ("proxyId") REFERENCES "proxies" ("id") ON DELETE SET NULL ON UPDATE CASCADE
);

CREATE TABLE "proxies" (
    "id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
    "fullName" TEXT NOT NULL,
    "contact" TEXT NOT NULL,
    "role" TEXT,
    "description" TEXT,
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" DATETIME NOT NULL
, email TEXT, phone TEXT);

CREATE TABLE "sponsorships" (
    "id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
    "childId" INTEGER NOT NULL,
    "sponsorId" INTEGER NOT NULL,
    "startDate" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "endDate" DATETIME,
    "monthlyAmount" REAL,
    "paymentMethod" TEXT,
    "isActive" BOOLEAN NOT NULL DEFAULT true,
    "notes" TEXT,
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" DATETIME NOT NULL,
    CONSTRAINT "sponsorships_childId_fkey" FOREIGN KEY ("childId") REFERENCES "children" ("id") ON DELETE RESTRICT ON UPDATE CASCADE,
    CONSTRAINT "sponsorships_sponsorId_fkey" FOREIGN KEY ("sponsorId") REFERENCES "sponsors" ("id") ON DELETE RESTRICT ON UPDATE CASCADE
);

CREATE TABLE "volunteers" (
    "id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
    "firstName" TEXT NOT NULL,
    "lastName" TEXT NOT NULL,
    "email" TEXT NOT NULL,
    "phone" TEXT,
    "role" TEXT NOT NULL DEFAULT 'volunteer',
    "isActive" BOOLEAN NOT NULL DEFAULT true,
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" DATETIME NOT NULL
);

COMMIT;
